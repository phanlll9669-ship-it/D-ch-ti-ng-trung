import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  AlignLeft,
  Table as TableIcon,
  MessageSquare,
  BookOpen,
  FileText,
  Volume2,
  VolumeX,
  Copy,
  Check,
  Download,
  Share2,
  Layers,
  HelpCircle,
  Clock,
  Gauge,
} from 'lucide-react';
import { Header } from './components/Header';
import { InputArea } from './components/InputArea';
import { StandardResultView } from './components/StandardResultView';
import { RubyResultView } from './components/RubyResultView';
import { VocabularyTableView } from './components/VocabularyTableView';
import { AnalysisView } from './components/AnalysisView';
import { DialogueView } from './components/DialogueView';
import { CharacterInspectorModal } from './components/CharacterInspectorModal';
import { SavedWordsDrawer } from './components/SavedWordsDrawer';
import { HistoryDrawer } from './components/HistoryDrawer';
import { RulesGuideModal } from './components/RulesGuideModal';
import { ShadowingModal } from './components/ShadowingModal';
import {
  TranslationResult,
  SavedWord,
  TranslationHistoryItem,
} from './types';
import { PRESETS } from './presets';
import { playMandarinTTS, stopAudio } from './utils/audio';

type ViewTab = 'standard' | 'ruby' | 'vocabulary' | 'analysis' | 'dialogue';

const SAVED_WORDS_STORAGE_KEY = 'chinese_assistant_saved_words';
const HISTORY_STORAGE_KEY = 'chinese_assistant_history';

export default function App() {
  const [input, setInput] = useState<string>(
    '你好，很高兴认识你。请问你是第一次来中国吗？如果是的话，祝你旅途愉快！'
  );
  const [result, setResult] = useState<TranslationResult | null>(null);
  const [isLoading, setIsLoading] = useState<boolean>(false);
  const [isOcrLoading, setIsOcrLoading] = useState<boolean>(false);
  const [includeAnalysis, setIncludeAnalysis] = useState<boolean>(true);
  const [activeTab, setActiveTab] = useState<ViewTab>('standard');
  const [audioRate, setAudioRate] = useState<number>(1.0);
  const [isGlobalAudioPlaying, setIsGlobalAudioPlaying] = useState<boolean>(false);

  const [inspectingWord, setInspectingWord] = useState<{ word: string; contextSentence?: string } | null>(null);
  const [isRulesOpen, setIsRulesOpen] = useState<boolean>(false);
  const [isSavedWordsOpen, setIsSavedWordsOpen] = useState<boolean>(false);
  const [isHistoryOpen, setIsHistoryOpen] = useState<boolean>(false);
  const [isShadowingOpen, setIsShadowingOpen] = useState<boolean>(false);

  // Attached Image state (from paste or upload)
  const [attachedImage, setAttachedImage] = useState<{ dataUrl: string; name: string; size?: string } | null>(null);
  const [uncertainChars, setUncertainChars] = useState<string[]>([]);

  // Storage states
  const [savedWords, setSavedWords] = useState<SavedWord[]>(() => {
    try {
      const data = localStorage.getItem(SAVED_WORDS_STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  });

  const [history, setHistory] = useState<TranslationHistoryItem[]>(() => {
    try {
      const data = localStorage.getItem(HISTORY_STORAGE_KEY);
      return data ? JSON.parse(data) : [];
    } catch {
      return [];
    }
  });

  const [copiedAll, setCopiedAll] = useState<boolean>(false);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  // Sync saved words
  useEffect(() => {
    try {
      localStorage.setItem(SAVED_WORDS_STORAGE_KEY, JSON.stringify(savedWords));
    } catch (e) {
      console.error(e);
    }
  }, [savedWords]);

  // Sync history
  useEffect(() => {
    try {
      localStorage.setItem(HISTORY_STORAGE_KEY, JSON.stringify(history));
    } catch (e) {
      console.error(e);
    }
  }, [history]);

  // Auto translate the initial sample text on first mount
  useEffect(() => {
    handleTranslate(input);
  }, []);

  const handleTranslate = async (textToTranslate?: string) => {
    const text = (textToTranslate !== undefined ? textToTranslate : input).trim();
    if (!text) return;

    setIsLoading(true);
    setErrorMessage(null);
    stopAudio();
    setIsGlobalAudioPlaying(false);

    try {
      const res = await fetch('/api/translate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          text,
          mode: 'standard',
          includeAnalysis: true,
        }),
      });

      const contentType = res.headers.get('content-type') || '';
      if (!res.ok || !contentType.includes('application/json')) {
        let errMsg = 'Không thể xử lý bản dịch tiếng Trung vào lúc này.';
        if (contentType.includes('application/json')) {
          const errData = await res.json().catch(() => ({}));
          errMsg = errData.error || errData.details || errMsg;
        }
        throw new Error(errMsg);
      }

      const data: TranslationResult = await res.json();
      setResult(data);

      // Auto route to dialogue tab if textType is dialogue
      if (data.textType === 'dialogue') {
        setActiveTab('dialogue');
      }

      // Add to history
      const historyItem: TranslationHistoryItem = {
        id: `${Date.now()}-${Math.random().toString(36).substring(2, 6)}`,
        input: text,
        overallVietnamese: data.overallVietnamese,
        timestamp: Date.now(),
        sentencesCount: data.sentences.length,
        detectedScript: data.detectedScript,
        data,
      };

      setHistory((prev) => [historyItem, ...prev.slice(0, 49)]);
    } catch (err: any) {
      console.error('Translation error:', err);
      setErrorMessage(err.message || 'Không thể dịch vào lúc này. Vui lòng thử lại.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleImageUploaded = async (base64: string, mimeType: string, fileName?: string) => {
    setIsOcrLoading(true);
    setErrorMessage(null);
    setAttachedImage({
      dataUrl: base64,
      name: fileName || `anh-chup-${Date.now()}.png`,
    });
    setUncertainChars([]);

    try {
      const res = await fetch('/api/ocr', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ imageBase64: base64, mimeType }),
      });

      const contentType = res.headers.get('content-type') || '';
      if (!res.ok || !contentType.includes('application/json')) {
        let errMsg = 'Lỗi nhận diện ảnh (OCR). Vui lòng thử lại với ảnh rõ nét hơn.';
        if (contentType.includes('application/json')) {
          const errData = await res.json().catch(() => ({}));
          errMsg = errData.error || errData.details || errMsg;
        }
        throw new Error(errMsg);
      }

      const ocrData = await res.json();
      if (ocrData.uncertainCharacters && ocrData.uncertainCharacters.length > 0) {
        setUncertainChars(ocrData.uncertainCharacters);
      }
      if (ocrData.extractedText) {
        setInput(ocrData.extractedText);
        handleTranslate(ocrData.extractedText);
      }
    } catch (err: any) {
      console.error('OCR Error:', err);
      setErrorMessage(err.message || 'Không thể nhận diện chữ Hán trong ảnh.');
    } finally {
      setIsOcrLoading(false);
    }
  };

  // Word save/remove
  const handleSaveWord = (word: SavedWord) => {
    if (savedWords.some((w) => w.chinese === word.chinese)) {
      setSavedWords((prev) => prev.filter((w) => w.chinese !== word.chinese));
    } else {
      setSavedWords((prev) => [word, ...prev]);
    }
  };

  const handleRemoveWord = (chinese: string) => {
    setSavedWords((prev) => prev.filter((w) => w.chinese !== chinese));
  };

  const isWordSaved = (chinese: string): boolean => {
    return savedWords.some((w) => w.chinese === chinese);
  };

  // Inspect word modal
  const handleInspectWord = (word: string, contextSentence?: string) => {
    setInspectingWord({ word, contextSentence });
  };

  // Global Audio: Play all sentences sequentially
  const handlePlayAll = async () => {
    if (!result) return;
    if (isGlobalAudioPlaying) {
      stopAudio();
      setIsGlobalAudioPlaying(false);
      return;
    }

    setIsGlobalAudioPlaying(true);
    try {
      const fullChinese = result.sentences.map((s) => s.chinese).join(' ');
      await playMandarinTTS(fullChinese, audioRate);
    } finally {
      setIsGlobalAudioPlaying(false);
    }
  };

  // Copy entire standard output formatted as required by the prompt
  const handleCopyAll = async () => {
    if (!result) return;

    let fullFormatted = '';

    if (result.sentences.length === 1) {
      const s = result.sentences[0];
      fullFormatted = `Tiếng Trung:
${s.chinese}

Pinyin:
${s.pinyin}

Tiếng Việt:
${s.vietnamese}`;
    } else {
      fullFormatted = result.sentences
        .map(
          (s) => `[Câu ${s.index}]
Tiếng Trung:
${s.chinese}

Pinyin:
${s.pinyin}

Tiếng Việt:
${s.vietnamese}`
        )
        .join('\n\n');
    }

    await navigator.clipboard.writeText(fullFormatted);
    setCopiedAll(true);
    setTimeout(() => setCopiedAll(false), 2000);
  };

  // Export as text file
  const handleExportTextFile = () => {
    if (!result) return;
    const content = `TRỢ LÝ DỊCH TIẾNG TRUNG - PINYIN - TIẾNG VIỆT
=====================================================
Ngày dịch: ${new Date().toLocaleString()}
Chữ viết: ${result.detectedScript === 'traditional' ? 'Phồn thể (繁體)' : 'Giản thể (简体)'}
-----------------------------------------------------

BẢN DỊCH TỔNG QUAN:
${result.overallVietnamese}

ĐỐI CHIẾU TỪNG CÂU (QUY TẮC CHUẨN):
${result.sentences
  .map(
    (s) => `[Câu ${s.index}]
Tiếng Trung: ${s.chinese}
Pinyin:      ${s.pinyin}
Tiếng Việt:  ${s.vietnamese}
${s.notes ? `Ghi chú:     ${s.notes}\n` : ''}`
  )
  .join('\n')}

BẢNG TỪ VỰNG:
${result.vocabulary
  .map(
    (v) =>
      `${v.chinese.padEnd(8)} | ${v.pinyin.padEnd(14)} | ${v.hanViet.padEnd(12)} | ${v.meaning}`
  )
  .join('\n')}
`;

    const blob = new Blob([content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `ban-dich-tieng-trung-${Date.now()}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="min-h-screen flex flex-col bg-stone-50 text-stone-900">
      {/* App Header */}
      <Header
        onOpenRules={() => setIsRulesOpen(true)}
        onOpenHistory={() => setIsHistoryOpen(true)}
        onOpenSavedWords={() => setIsSavedWordsOpen(true)}
        savedWordsCount={savedWords.length}
        historyCount={history.length}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 space-y-6">
        {/* Input Card */}
        <InputArea
          input={input}
          setInput={setInput}
          onTranslate={handleTranslate}
          isLoading={isLoading}
          includeAnalysis={includeAnalysis}
          setIncludeAnalysis={setIncludeAnalysis}
          onImageUploaded={handleImageUploaded}
          isOcrLoading={isOcrLoading}
          attachedImage={attachedImage}
          onRemoveAttachedImage={() => {
            setAttachedImage(null);
            setUncertainChars([]);
          }}
          uncertainChars={uncertainChars}
        />

        {/* Error notification if any */}
        {errorMessage && (
          <div className="bg-red-50 border border-red-200 text-red-800 p-4 rounded-2xl text-sm flex items-center justify-between">
            <div>
              <span className="font-semibold">Thông báo: </span>
              <span>{errorMessage}</span>
            </div>
            <button
              onClick={() => setErrorMessage(null)}
              className="text-red-600 hover:text-red-900 font-semibold text-xs ml-4"
            >
              Đóng
            </button>
          </div>
        )}

        {/* Translation Output Section */}
        {result && (
          <div className="space-y-4">
            {/* View Mode Tabs & Output Toolbar */}
            <div className="bg-white p-2.5 rounded-2xl border border-stone-200/90 shadow-2xs flex flex-wrap items-center justify-between gap-3">
              {/* Tab Navigation */}
              <div className="flex items-center gap-1 overflow-x-auto scrollbar-none">
                {/* 1. Standard View */}
                <button
                  type="button"
                  onClick={() => setActiveTab('standard')}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 ${
                    activeTab === 'standard'
                      ? 'bg-red-600 text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
                  }`}
                >
                  <AlignLeft className="w-4 h-4" />
                  <span>Đối Chiếu Từng Câu</span>
                </button>

                {/* 2. Ruby Pinyin View */}
                <button
                  type="button"
                  onClick={() => setActiveTab('ruby')}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 ${
                    activeTab === 'ruby'
                      ? 'bg-red-600 text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
                  }`}
                >
                  <span className="font-chinese text-sm">拼</span>
                  <span>Ruby Pinyin</span>
                </button>

                {/* 3. Vocabulary Table View */}
                <button
                  type="button"
                  onClick={() => setActiveTab('vocabulary')}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 ${
                    activeTab === 'vocabulary'
                      ? 'bg-red-600 text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
                  }`}
                >
                  <TableIcon className="w-4 h-4" />
                  <span>Bảng Từ Vựng ({result.vocabulary.length})</span>
                </button>

                {/* 4. Deep Analysis View */}
                <button
                  type="button"
                  onClick={() => setActiveTab('analysis')}
                  className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 ${
                    activeTab === 'analysis'
                      ? 'bg-red-600 text-white shadow-xs'
                      : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
                  }`}
                >
                  <BookOpen className="w-4 h-4" />
                  <span>Ngữ Pháp & Đa Âm</span>
                </button>

                {/* 5. Dialogue View */}
                {result.textType === 'dialogue' && (
                  <button
                    type="button"
                    onClick={() => setActiveTab('dialogue')}
                    className={`inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs sm:text-sm font-semibold transition-all shrink-0 ${
                      activeTab === 'dialogue'
                        ? 'bg-red-600 text-white shadow-xs'
                        : 'text-stone-600 hover:text-stone-900 hover:bg-stone-100'
                    }`}
                  >
                    <MessageSquare className="w-4 h-4" />
                    <span>Hội Thoại</span>
                  </button>
                )}
              </div>

              {/* Utility Tools on the right */}
              <div className="flex items-center gap-2 ml-auto flex-wrap">
                {/* Play Rate Selector */}
                <div className="flex items-center gap-1 bg-stone-100 px-2 py-1 rounded-lg text-xs font-medium text-stone-600">
                  <Gauge className="w-3.5 h-3.5 text-stone-400" />
                  <select
                    value={audioRate}
                    onChange={(e) => setAudioRate(parseFloat(e.target.value))}
                    className="bg-transparent focus:outline-hidden font-semibold cursor-pointer text-stone-800"
                    title="Tốc độ phát âm"
                  >
                    <option value={0.75}>0.75x (Chậm)</option>
                    <option value={1.0}>1.0x (Chuẩn)</option>
                    <option value={1.25}>1.25x (Nhanh)</option>
                  </select>
                </div>

                {/* Listen All Button */}
                <button
                  type="button"
                  onClick={handlePlayAll}
                  className={`inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                    isGlobalAudioPlaying
                      ? 'bg-red-600 text-white'
                      : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                  }`}
                  title="Nghe toàn bộ văn bản tiếng Trung"
                >
                  {isGlobalAudioPlaying ? (
                    <>
                      <VolumeX className="w-3.5 h-3.5" />
                      <span>Dừng nghe</span>
                    </>
                  ) : (
                    <>
                      <Volume2 className="w-3.5 h-3.5" />
                      <span>Nghe toàn bài</span>
                    </>
                  )}
                </button>

                {/* Copy All Formatted */}
                <button
                  type="button"
                  onClick={handleCopyAll}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors"
                  title="Sao chép toàn bộ bản dịch theo định dạng chuẩn quy định"
                >
                  {copiedAll ? (
                    <>
                      <Check className="w-3.5 h-3.5 text-emerald-600" />
                      <span className="text-emerald-700">Đã chép</span>
                    </>
                  ) : (
                    <>
                      <Copy className="w-3.5 h-3.5" />
                      <span>Chép toàn bộ</span>
                    </>
                  )}
                </button>

                {/* Export File */}
                <button
                  type="button"
                  onClick={handleExportTextFile}
                  className="inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs font-semibold bg-stone-100 hover:bg-stone-200 text-stone-700 transition-colors"
                  title="Xuất kết quả thành tệp văn bản .txt"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>Xuất file</span>
                </button>
              </div>
            </div>

            {/* Overall Vietnamese Summary Card (for longer passages) & Shadowing Trigger */}
            {result.sentences.length > 0 && (
              <div className="bg-emerald-50/60 rounded-2xl p-4 border border-emerald-200/60 shadow-2xs flex flex-wrap items-center justify-between gap-4">
                <div className="flex-1">
                  <span className="text-xs font-bold uppercase tracking-wider text-emerald-800 block mb-1">
                    Ý nghĩa tổng thể mượt mà:
                  </span>
                  <p className="text-sm sm:text-base text-stone-900 font-medium leading-relaxed">
                    {result.overallVietnamese}
                  </p>
                </div>

                <button
                  type="button"
                  onClick={() => setIsShadowingOpen(true)}
                  className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-red-600 hover:bg-red-700 active:bg-red-800 text-white font-bold text-sm shadow-md shadow-red-600/20 transition-all shrink-0"
                  title="Mở giao diện luyện nói và nghe Shadowing cho đoạn văn này"
                >
                  <Sparkles className="w-4 h-4" />
                  <span>🎧 Luyện Shadowing</span>
                </button>
              </div>
            )}

            {/* Active View Tab Content */}
            {activeTab === 'standard' && (
              <StandardResultView
                sentences={result.sentences}
                overallVietnamese={result.overallVietnamese}
                onInspectWord={handleInspectWord}
                onSaveWord={handleSaveWord}
                isWordSaved={isWordSaved}
                audioRate={audioRate}
              />
            )}

            {activeTab === 'ruby' && (
              <RubyResultView
                sentences={result.sentences}
                onInspectWord={handleInspectWord}
                audioRate={audioRate}
              />
            )}

            {activeTab === 'vocabulary' && (
              <VocabularyTableView
                vocabulary={result.vocabulary}
                onInspectWord={handleInspectWord}
                onSaveWord={handleSaveWord}
                isWordSaved={isWordSaved}
                audioRate={audioRate}
              />
            )}

            {activeTab === 'analysis' && (
              <AnalysisView
                grammarPoints={result.grammarPoints}
                slangOrIdioms={result.slangOrIdioms}
                specialDisambiguations={result.specialDisambiguations}
                textType={result.textType}
              />
            )}

            {activeTab === 'dialogue' && (
              <DialogueView
                sentences={result.sentences}
                onInspectWord={handleInspectWord}
                audioRate={audioRate}
              />
            )}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-stone-200/80 bg-white py-6 mt-12 text-center text-xs text-stone-500">
        <div className="max-w-7xl mx-auto px-4 space-y-2">
          <p className="font-medium text-stone-700">
            Trợ Lý Dịch Tiếng Trung &bull; Phiên Âm Hanyu Pinyin Chuẩn &bull; Tiếng Việt Tự Nhiên
          </p>
          <p className="text-stone-400">
            Tuân thủ nghiêm ngặt quy tắc đối chiếu từng câu, biến điệu thanh điệu, chữ đa âm (多音字), thành ngữ (成语) và ngữ cảnh chuyên ngành.
          </p>
        </div>
      </footer>

      {/* Modals & Drawers */}
      <CharacterInspectorModal
        word={inspectingWord?.word || null}
        contextSentence={inspectingWord?.contextSentence}
        onClose={() => setInspectingWord(null)}
        onSaveWord={handleSaveWord}
        isWordSaved={isWordSaved}
        audioRate={audioRate}
      />

      <SavedWordsDrawer
        isOpen={isSavedWordsOpen}
        onClose={() => setIsSavedWordsOpen(false)}
        savedWords={savedWords}
        onRemoveWord={handleRemoveWord}
        onInspectWord={(w) => handleInspectWord(w)}
        audioRate={audioRate}
      />

      <HistoryDrawer
        isOpen={isHistoryOpen}
        onClose={() => setIsHistoryOpen(false)}
        history={history}
        onSelectHistory={(item) => {
          setInput(item.input);
          setResult(item.data);
        }}
        onClearHistory={() => setHistory([])}
      />

      <RulesGuideModal
        isOpen={isRulesOpen}
        onClose={() => setIsRulesOpen(false)}
      />

      {result && (
        <ShadowingModal
          isOpen={isShadowingOpen}
          onClose={() => setIsShadowingOpen(false)}
          result={result}
          audioRate={audioRate}
        />
      )}
    </div>
  );
}
