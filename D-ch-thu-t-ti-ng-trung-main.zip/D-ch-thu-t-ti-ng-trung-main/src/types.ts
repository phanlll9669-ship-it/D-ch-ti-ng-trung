export interface Token {
  chinese: string;
  pinyin: string;
  hanViet?: string;
  meaning: string;
}

export interface SentenceItem {
  index: number;
  speaker?: string | null;
  chinese: string;
  pinyin: string;
  vietnamese: string;
  tokens: Token[];
  notes?: string | null;
}

export interface VocabularyItem {
  chinese: string;
  pinyin: string;
  hanViet: string;
  meaning: string;
  partOfSpeech: string;
  hskLevel?: string | null;
  exampleSentence?: string | null;
  examplePinyin?: string | null;
  exampleMeaning?: string | null;
}

export interface GrammarPoint {
  pattern: string;
  explanation: string;
  example?: string;
}

export interface SlangOrIdiom {
  term: string;
  pinyin: string;
  literalMeaning?: string;
  actualMeaning: string;
  contextNote?: string;
}

export interface SpecialDisambiguation {
  character: string;
  usedReading: string;
  otherReadings: string;
  ruleExplanation: string;
}

export interface TranslationResult {
  detectedScript: 'simplified' | 'traditional' | 'mixed';
  textType: string;
  overallVietnamese: string;
  formattedStandardText: string;
  sentences: SentenceItem[];
  vocabulary: VocabularyItem[];
  grammarPoints?: GrammarPoint[];
  slangOrIdioms?: SlangOrIdiom[];
  specialDisambiguations?: SpecialDisambiguation[];
}

export interface CharDetail {
  simplified: string;
  traditional: string;
  pinyin: string;
  hanViet: string;
  radical: string;
  strokeCount: number;
  hskLevel: string;
  partOfSpeech?: string;
  primaryMeaning: string;
  polyphoneReadings?: Array<{
    reading: string;
    meaning: string;
    sampleWord?: string;
  }>;
  compoundWords: Array<{
    word: string;
    pinyin: string;
    hanViet?: string;
    meaning: string;
  }>;
  examples: Array<{
    chinese: string;
    pinyin: string;
    vietnamese: string;
  }>;
}

export interface SavedWord {
  id: string;
  chinese: string;
  pinyin: string;
  hanViet: string;
  meaning: string;
  partOfSpeech?: string;
  hskLevel?: string;
  createdAt: number;
}

export interface TranslationHistoryItem {
  id: string;
  input: string;
  overallVietnamese: string;
  timestamp: number;
  sentencesCount: number;
  detectedScript: string;
  data: TranslationResult;
}
