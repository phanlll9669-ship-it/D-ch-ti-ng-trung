import React, { useRef, useState, useEffect } from 'react';
import {
  Sparkles,
  Image as ImageIcon,
  Trash2,
  Loader2,
  ArrowRight,
  BookMarked,
  Camera,
  ClipboardPaste,
  X,
  AlertTriangle,
  ZoomIn,
  Smartphone,
} from 'lucide-react';
import { PRESETS, PresetItem } from '../presets';

interface InputAreaProps {
  input: string;
  setInput: (val: string) => void;
  onTranslate: (textToTranslate?: string) => void;
  isLoading: boolean;
  includeAnalysis: boolean;
  setIncludeAnalysis: (val: boolean) => void;
  onImageUploaded: (base64: string, mimeType: string, fileName?: string) => void;
  isOcrLoading: boolean;
  attachedImage: { dataUrl: string; name: string; size?: string } | null;
  onRemoveAttachedImage: () => void;
  uncertainChars?: string[];
}

// Compress and resize high-res phone camera images (10MP-48MP) on canvas
async function compressImageForMobile(
  file: File | Blob,
  maxDimension = 2048,
  quality = 0.85
): Promise<{ base64: string; mimeType: string }> {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      const img = new Image();
      img.onload = () => {
        let width = img.width;
        let height = img.height;

        if (width > maxDimension || height > maxDimension) {
          if (width > height) {
            height = Math.round((height * maxDimension) / width);
            width = maxDimension;
          } else {
            width = Math.round((width * maxDimension) / height);
            height = maxDimension;
          }
        }

        const canvas = document.createElement('canvas');
        canvas.width = width;
        canvas.height = height;
        const ctx = canvas.getContext('2d');
        if (!ctx) {
          resolve({ base64: dataUrl, mimeType: file.type || 'image/jpeg' });
          return;
        }

        ctx.drawImage(img, 0, 0, width, height);
        const compressedDataUrl = canvas.toDataURL('image/jpeg', quality);
        resolve({ base64: compressedDataUrl, mimeType: 'image/jpeg' });
      };
      img.onerror = () => {
        resolve({ base64: dataUrl, mimeType: file.type || 'image/jpeg' });
      };
      img.src = dataUrl;
    };
    reader.onerror = reject;
    reader.readAsDataURL(file);
  });
}

export const InputArea: React.FC<InputAreaProps> = ({
  input,
  setInput,
  onTranslate,
  isLoading,
  includeAnalysis,
  setIncludeAnalysis,
  onImageUploaded,
  isOcrLoading,
  attachedImage,
  onRemoveAttachedImage,
  uncertainChars = [],
}) => {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const cameraInputRef = useRef<HTMLInputElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const [selectedPresetId, setSelectedPresetId] = useState<string>('');
  const [isDragOver, setIsDragOver] = useState(false);
  const [pasteNotice, setPasteNotice] = useState<string | null>(null);
  const [isImageModalOpen, setIsImageModalOpen] = useState(false);
  const [isProcessingPhoneImage, setIsProcessingPhoneImage] = useState(false);

  // Quick stats
  const charCount = input.trim().length;
  const isTraditionalEstimate = /[\u4e00-\u9fa5]/.test(input) && /[繁體灣門國時發學愛實體買賣廣]/i.test(input);

  const processImageFile = async (file: File | Blob, customName?: string) => {
    const fileName = customName || (file instanceof File ? file.name : `anh-dien-thoai-${Date.now()}.jpg`);
    setIsProcessingPhoneImage(true);

    try {
      // Auto-compress heavy mobile phone photos to ensure ultra-fast processing
      const { base64, mimeType } = await compressImageForMobile(file, 2048, 0.85);
      onImageUploaded(base64, mimeType, fileName);
      setPasteNotice(`Đã nhận ảnh: ${fileName}`);
      setTimeout(() => setPasteNotice(null), 3500);
    } catch (err) {
      console.error('Image compression error, using raw file:', err);
      const reader = new FileReader();
      reader.onload = () => {
        const result = reader.result as string;
        onImageUploaded(result, file.type || 'image/jpeg', fileName);
      };
      reader.readAsDataURL(file);
    } finally {
      setIsProcessingPhoneImage(false);
    }
  };

  // Listen to paste events globally and on textarea
  useEffect(() => {
    const handleGlobalPaste = (e: ClipboardEvent) => {
      const items = e.clipboardData?.items;
      if (!items) return;

      for (let i = 0; i < items.length; i++) {
        const item = items[i];
        if (item.type.startsWith('image/')) {
          e.preventDefault();
          const file = item.getAsFile();
          if (file) {
            processImageFile(file, `anh-dan-clipboard-${Date.now().toString().slice(-4)}.jpg`);
          }
          return;
        }
      }
    };

    window.addEventListener('paste', handleGlobalPaste);
    return () => {
      window.removeEventListener('paste', handleGlobalPaste);
    };
  }, []);

  const handleTextareaPaste = (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    const items = e.clipboardData?.items;
    if (!items) return;

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      if (item.type.startsWith('image/')) {
        e.preventDefault();
        const file = item.getAsFile();
        if (file) {
          processImageFile(file, `anh-dan-dien-thoai-${Date.now().toString().slice(-4)}.jpg`);
        }
        return;
      }
    }
  };

  const handleSelectPreset = (preset: PresetItem) => {
    setSelectedPresetId(preset.id);
    setInput(preset.chinese);
    onTranslate(preset.chinese);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processImageFile(file, file.name);
    e.target.value = '';
  };

  const handleCameraChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    processImageFile(file, `anh-chup-camera-${new Date().toLocaleTimeString().replace(/:/g, '')}.jpg`);
    e.target.value = '';
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(false);
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      const file = e.dataTransfer.files[0];
      if (file.type.startsWith('image/')) {
        processImageFile(file, file.name);
      }
    }
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    setIsDragOver(true);
  };

  const handleDragLeave = () => {
    setIsDragOver(false);
  };

  // Direct paste button from clipboard (works on phones and computers)
  const handlePasteButtonClick = async () => {
    try {
      if (navigator.clipboard && navigator.clipboard.read) {
        const items = await navigator.clipboard.read();
        for (const item of items) {
          for (const type of item.types) {
            if (type.startsWith('image/')) {
              const blob = await item.getType(type);
              processImageFile(blob, `anh-dan-clipboard-${Date.now().toString().slice(-4)}.jpg`);
              return;
            }
          }
        }
      }

      // If no image blob is found, try reading text or guide user
      setPasteNotice('📱 Trên điện thoại: Chạm giữ ô nhập rồi chọn "Dán", hoặc dùng nút "Chụp ảnh / Thư viện". Trên máy tính: nhấn Ctrl+V.');
      setTimeout(() => setPasteNotice(null), 5000);
      textareaRef.current?.focus();
    } catch (err) {
      setPasteNotice('📱 Chạm giữ vào ô nhập liệu bên dưới rồi chọn "Dán" (Paste) ảnh từ điện thoại!');
      setTimeout(() => setPasteNotice(null), 5000);
      textareaRef.current?.focus();
    }
  };

  return (
    <div className="bg-white rounded-2xl border border-stone-200/90 shadow-sm overflow-hidden transition-all">
      {/* Presets Bar */}
      <div className="bg-stone-50/80 px-4 py-2.5 border-b border-stone-200/80">
        <div className="flex items-center justify-between mb-1.5">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-stone-600">
            <BookMarked className="w-3.5 h-3.5 text-red-600" />
            <span>Ví dụ minh họa theo từng chuyên mục quy tắc:</span>
          </div>
          <span className="text-[11px] text-stone-400 hidden sm:inline">Nhấp để thử nghiệm ngay</span>
        </div>
        <div className="flex items-center gap-1.5 overflow-x-auto pb-1 scrollbar-none text-xs">
          {PRESETS.map((p) => {
            const isSelected = selectedPresetId === p.id && input === p.chinese;
            return (
              <button
                key={p.id}
                type="button"
                onClick={() => handleSelectPreset(p)}
                className={`px-2.5 py-1 rounded-lg font-medium whitespace-nowrap transition-all border shrink-0 text-left ${
                  isSelected
                    ? 'bg-red-600 text-white border-red-600 shadow-xs'
                    : 'bg-white hover:bg-stone-100 text-stone-700 border-stone-200 hover:border-stone-300'
                }`}
                title={p.description}
              >
                {p.title}
              </button>
            );
          })}
        </div>
      </div>

      {/* Attached Image Preview Card (if an image was uploaded or pasted) */}
      {attachedImage && (
        <div className="px-4 pt-3 pb-1">
          <div className="bg-stone-50 border border-stone-200/90 rounded-xl p-2.5 flex items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div
                onClick={() => setIsImageModalOpen(true)}
                className="relative w-12 h-12 rounded-lg overflow-hidden border border-stone-200 shrink-0 cursor-pointer group bg-stone-100"
                title="Nhấp để xem ảnh lớn"
              >
                <img
                  src={attachedImage.dataUrl}
                  alt={attachedImage.name}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform"
                />
                <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                  <ZoomIn className="w-4 h-4 text-white drop-shadow-xs" />
                </div>
              </div>

              <div className="text-xs">
                <div className="flex items-center gap-2">
                  <span className="font-semibold text-stone-800 line-clamp-1 max-w-[200px] sm:max-w-xs">
                    {attachedImage.name}
                  </span>
                  <span className="px-1.5 py-0.2 rounded text-[10px] font-bold bg-red-100 text-red-800">
                    Ảnh OCR
                  </span>
                </div>
                <p className="text-stone-500 text-[11px] mt-0.5">
                  Đã nhận diện chữ Hán &bull; Bạn có thể chỉnh sửa văn bản bên dưới trước khi dịch
                </p>
              </div>
            </div>

            <div className="flex items-center gap-1.5">
              <button
                type="button"
                onClick={onRemoveAttachedImage}
                className="p-1.5 text-stone-400 hover:text-red-600 hover:bg-stone-200/60 rounded-lg transition-colors"
                title="Xóa ảnh này"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Uncertain Characters Warning Badge (Rule 5 compliance) */}
          {uncertainChars && uncertainChars.length > 0 && (
            <div className="mt-2 bg-amber-50 border border-amber-200 rounded-lg p-2.5 text-xs text-amber-900 flex items-start gap-2">
              <AlertTriangle className="w-4 h-4 text-amber-600 shrink-0 mt-0.5" />
              <div>
                <span className="font-semibold">Lưu ý nhận diện ảnh: </span>
                <span>Có các chữ sau có thể bị mờ hoặc không chắc chắn 100%: </span>
                <span className="font-chinese font-bold text-amber-950 bg-amber-200/60 px-1.5 py-0.5 rounded ml-1">
                  {uncertainChars.join(', ')}
                </span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Paste Notification Banner */}
      {pasteNotice && (
        <div className="px-4 pt-2">
          <div className="bg-red-50 text-red-800 text-xs px-3 py-2 rounded-lg border border-red-200 flex items-center gap-2 animate-in fade-in">
            <ClipboardPaste className="w-4 h-4 text-red-600 shrink-0" />
            <span className="leading-snug">{pasteNotice}</span>
          </div>
        </div>
      )}

      {/* Main Textarea Area with Drag & Drop & Paste Listeners */}
      <div
        className={`relative p-4 transition-colors ${
          isDragOver ? 'bg-red-50/50 border-2 border-dashed border-red-400' : ''
        }`}
        onDrop={handleDrop}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
      >
        <textarea
          ref={textareaRef}
          value={input}
          onChange={(e) => {
            setInput(e.target.value);
            if (selectedPresetId) setSelectedPresetId('');
          }}
          onPaste={handleTextareaPaste}
          placeholder="Nhập hoặc dán chữ Hán vào đây... Hoặc chụp ảnh / dán ảnh từ điện thoại, máy tính để nhận diện tự động."
          className="w-full h-36 sm:h-40 resize-y p-1 text-base sm:text-lg font-chinese-sans text-stone-900 placeholder:text-stone-400 focus:outline-hidden leading-relaxed"
          disabled={isLoading || isOcrLoading || isProcessingPhoneImage}
        />

        {/* Drag Notice Overlay */}
        {isDragOver && (
          <div className="absolute inset-0 bg-red-50/90 flex flex-col items-center justify-center pointer-events-none rounded-xl">
            <Camera className="w-10 h-10 text-red-600 animate-bounce mb-2" />
            <p className="font-semibold text-red-900 text-sm">Thả ảnh chứa chữ Hán vào đây để nhận diện (OCR)</p>
          </div>
        )}

        {/* Loading OCR or Phone Image Processing Overlay */}
        {(isOcrLoading || isProcessingPhoneImage) && (
          <div className="absolute inset-0 bg-white/90 backdrop-blur-xs flex flex-col items-center justify-center z-10 rounded-xl">
            <Loader2 className="w-8 h-8 text-red-600 animate-spin mb-2" />
            <p className="font-semibold text-stone-800 text-sm">
              {isProcessingPhoneImage ? 'Đang tối ưu ảnh từ điện thoại...' : 'Đang trích xuất chữ Hán từ ảnh (OCR)...'}
            </p>
            <p className="text-xs text-stone-500 mt-1">
              Nhận diện chữ Hán Giản thể & Phồn thể, đánh dấu chữ mờ theo quy tắc
            </p>
          </div>
        )}
      </div>

      {/* Bottom Bar: Multi-device Image Tools & Action CTA */}
      <div className="px-4 py-3 bg-stone-50/50 border-t border-stone-200/80 flex flex-col gap-2.5">
        <div className="flex flex-wrap items-center justify-between gap-3">
          {/* Left Tools: Camera (Phone), Upload Gallery, Paste (Phone/PC), Analysis Checkbox */}
          <div className="flex items-center flex-wrap gap-2 text-xs">
            {/* 1. File Input for Gallery / Computer */}
            <input
              type="file"
              ref={fileInputRef}
              onChange={handleFileChange}
              accept="image/*"
              className="hidden"
            />

            {/* 2. Direct Camera Capture Input for Phone (Rear Camera) */}
            <input
              type="file"
              ref={cameraInputRef}
              onChange={handleCameraChange}
              accept="image/*"
              capture="environment"
              className="hidden"
            />

            {/* Button 1: Chụp ảnh (Camera điện thoại) */}
            <button
              type="button"
              onClick={() => cameraInputRef.current?.click()}
              disabled={isLoading || isOcrLoading || isProcessingPhoneImage}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium text-stone-700 bg-white border border-stone-200 hover:bg-stone-100 hover:text-stone-900 transition-colors shadow-2xs"
              title="Chụp ảnh trực tiếp bằng Camera điện thoại để dịch ngay"
            >
              <Camera className="w-3.5 h-3.5 text-red-600" />
              <span>Chụp ảnh</span>
            </button>

            {/* Button 2: Tải ảnh từ thư viện (Điện thoại hoặc Máy tính) */}
            <button
              type="button"
              onClick={() => fileInputRef.current?.click()}
              disabled={isLoading || isOcrLoading || isProcessingPhoneImage}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium text-stone-700 bg-white border border-stone-200 hover:bg-stone-100 hover:text-stone-900 transition-colors shadow-2xs"
              title="Chọn ảnh từ Thư viện ảnh điện thoại hoặc máy tính"
            >
              <ImageIcon className="w-3.5 h-3.5 text-amber-600" />
              <span>Thư viện ảnh</span>
            </button>

            {/* Button 3: Dán ảnh (Paste từ clipboard) */}
            <button
              type="button"
              onClick={handlePasteButtonClick}
              disabled={isLoading || isOcrLoading || isProcessingPhoneImage}
              className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium text-stone-700 bg-white border border-stone-200 hover:bg-stone-100 hover:text-stone-900 transition-colors shadow-2xs"
              title="Dán ảnh từ bộ nhớ tạm điện thoại (chạm giữ chọn Dán) hoặc nhấn Ctrl+V trên máy tính"
            >
              <ClipboardPaste className="w-3.5 h-3.5 text-emerald-600" />
              <span>Dán ảnh (Paste)</span>
            </button>

            {/* Toggle Analysis */}
            <label className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg cursor-pointer bg-white border border-stone-200 hover:border-stone-300 transition-colors text-stone-700 select-none shadow-2xs">
              <input
                type="checkbox"
                checked={includeAnalysis}
                onChange={(e) => setIncludeAnalysis(e.target.checked)}
                className="rounded text-red-600 focus:ring-red-500 w-3.5 h-3.5"
              />
              <span className="font-medium">Phân tích ngữ pháp & đa âm</span>
            </label>

            {/* Script Type & Char Count Badge */}
            {charCount > 0 && (
              <div className="flex items-center gap-2 pl-2 text-stone-500">
                <span>{charCount} ký tự</span>
                {isTraditionalEstimate ? (
                  <span className="px-2 py-0.5 rounded-md bg-amber-50 text-amber-800 border border-amber-200/70 font-semibold text-[11px]">
                    Phồn thể (繁體)
                  </span>
                ) : (
                  <span className="px-2 py-0.5 rounded-md bg-emerald-50 text-emerald-800 border border-emerald-200/70 font-semibold text-[11px]">
                    Giản thể (简体)
                  </span>
                )}
              </div>
            )}
          </div>

          {/* Right CTA */}
          <div className="flex items-center gap-2 ml-auto">
            {input && (
              <button
                type="button"
                onClick={() => {
                  setInput('');
                  setSelectedPresetId('');
                  onRemoveAttachedImage();
                }}
                disabled={isLoading || isOcrLoading || isProcessingPhoneImage}
                className="p-2 text-stone-400 hover:text-stone-700 hover:bg-stone-200/60 rounded-lg transition-colors"
                title="Xóa nội dung"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}

            <button
              type="button"
              onClick={() => onTranslate()}
              disabled={isLoading || isOcrLoading || isProcessingPhoneImage || !input.trim()}
              className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all shadow-sm ${
                isLoading || isProcessingPhoneImage || !input.trim()
                  ? 'bg-stone-200 text-stone-400 cursor-not-allowed'
                  : 'bg-red-600 hover:bg-red-700 active:bg-red-800 text-white shadow-red-600/20'
              }`}
            >
              {isLoading ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Đang xử lý dịch...</span>
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  <span>Dịch & Phiên Âm</span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </div>
        </div>

        {/* Helpful Tip for Mobile Users */}
        <div className="flex items-center gap-1.5 text-[11px] text-stone-500 pt-1 border-t border-stone-200/60">
          <Smartphone className="w-3.5 h-3.5 text-stone-400 shrink-0" />
          <span>
            <strong>Mẹo cho điện thoại:</strong> Bạn có thể nhấn <strong>"Chụp ảnh"</strong> để quét sách/menu ngay, chọn từ <strong>"Thư viện ảnh"</strong>, hoặc chạm & giữ vào ô nhập liệu rồi chọn <strong>"Dán" (Paste)</strong> ảnh từ bộ nhớ tạm.
          </span>
        </div>
      </div>

      {/* Modal to view enlarged attached image */}
      {isImageModalOpen && attachedImage && (
        <div
          className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/70 backdrop-blur-xs"
          onClick={() => setIsImageModalOpen(false)}
        >
          <div
            className="bg-white rounded-2xl max-w-2xl w-full p-4 overflow-hidden shadow-2xl space-y-3"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="flex items-center justify-between border-b pb-2">
              <span className="font-bold text-stone-800 text-sm">{attachedImage.name}</span>
              <button
                onClick={() => setIsImageModalOpen(false)}
                className="p-1 text-stone-400 hover:text-stone-700 rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            <div className="max-h-[70vh] overflow-auto flex items-center justify-center bg-stone-100 rounded-xl p-2">
              <img
                src={attachedImage.dataUrl}
                alt="Enlarged"
                className="max-h-[65vh] w-auto object-contain rounded-lg shadow-xs"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
