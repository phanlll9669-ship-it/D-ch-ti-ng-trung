import React from 'react';
import {
  BookOpen,
  Split,
  MessageSquareQuote,
  Sparkles,
  Info,
  CheckCircle,
  AlertTriangle,
} from 'lucide-react';
import { GrammarPoint, SlangOrIdiom, SpecialDisambiguation } from '../types';

interface AnalysisViewProps {
  grammarPoints?: GrammarPoint[];
  slangOrIdioms?: SlangOrIdiom[];
  specialDisambiguations?: SpecialDisambiguation[];
  textType: string;
}

export const AnalysisView: React.FC<AnalysisViewProps> = ({
  grammarPoints,
  slangOrIdioms,
  specialDisambiguations,
  textType,
}) => {
  const hasGrammar = grammarPoints && grammarPoints.length > 0;
  const hasSlang = slangOrIdioms && slangOrIdioms.length > 0;
  const hasDisambiguations = specialDisambiguations && specialDisambiguations.length > 0;

  return (
    <div className="space-y-6">
      {/* 1. Polyphone & Tone Sandhi Disambiguation */}
      {hasDisambiguations && (
        <div className="bg-white rounded-2xl p-6 border border-stone-200/90 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 text-stone-900 font-bold text-base">
            <Split className="w-5 h-5 text-red-600" />
            <span>Phân biệt Chữ Đa Âm (多音字) & Biến Điệu Thanh Điệu</span>
          </div>
          <p className="text-xs text-stone-500">
            Theo quy tắc chuyên gia: xác định chính xác cách đọc theo ngữ cảnh câu, đối chiếu các âm tiết khác.
          </p>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
            {specialDisambiguations.map((item, idx) => (
              <div
                key={idx}
                className="bg-stone-50/80 rounded-xl p-4 border border-stone-200/80 space-y-2.5"
              >
                <div className="flex items-center justify-between">
                  <span className="text-2xl font-chinese font-bold text-stone-900">
                    {item.character}
                  </span>
                  <div className="flex items-center gap-1.5">
                    <span className="text-xs px-2 py-0.5 rounded-md bg-red-100 text-red-800 font-semibold font-sans">
                      Cách đọc ở đây: {item.usedReading}
                    </span>
                  </div>
                </div>

                <div className="text-xs space-y-1">
                  <div className="text-stone-600">
                    <span className="font-semibold text-stone-700">Các âm khác: </span>
                    <span className="font-sans text-stone-600">{item.otherReadings}</span>
                  </div>
                  <div className="text-stone-700 bg-white p-2.5 rounded-lg border border-stone-200/60 leading-relaxed">
                    <span className="font-semibold text-red-700">Lý do chọn: </span>
                    {item.ruleExplanation}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 2. Thành ngữ (成语) & Tiếng lóng mạng */}
      {hasSlang && (
        <div className="bg-white rounded-2xl p-6 border border-stone-200/90 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 text-stone-900 font-bold text-base">
            <MessageSquareQuote className="w-5 h-5 text-amber-600" />
            <span>Thành Ngữ Tứ Tự (成语), Tiếng Lóng & Thuật Ngữ Mạng</span>
          </div>
          <p className="text-xs text-stone-500">
            Quy tắc bắt buộc: Giải thích nghĩa thực tế trong đời sống thay vì dịch thô từng chữ gây hiểu lầm.
          </p>

          <div className="space-y-3 pt-1">
            {slangOrIdioms.map((item, idx) => (
              <div
                key={idx}
                className="bg-amber-50/50 rounded-xl p-4 border border-amber-200/60 space-y-2"
              >
                <div className="flex items-baseline justify-between flex-wrap gap-2">
                  <div className="flex items-baseline gap-2">
                    <span className="text-xl font-chinese font-bold text-stone-900">
                      {item.term}
                    </span>
                    <span className="text-sm font-sans font-semibold text-red-700">
                      [{item.pinyin}]
                    </span>
                  </div>
                  {item.literalMeaning && (
                    <span className="text-xs text-stone-500">
                      Nghĩa đen: <span className="italic">{item.literalMeaning}</span>
                    </span>
                  )}
                </div>

                <div className="text-sm text-stone-900 font-medium bg-white p-3 rounded-lg border border-amber-200/40">
                  <span className="font-semibold text-amber-800">Nghĩa thực tế: </span>
                  {item.actualMeaning}
                </div>

                {item.contextNote && (
                  <div className="text-xs text-stone-600 flex items-start gap-1.5 pl-1">
                    <Info className="w-3.5 h-3.5 text-stone-400 shrink-0 mt-0.5" />
                    <span>{item.contextNote}</span>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* 3. Ngữ pháp & Cấu trúc câu */}
      {hasGrammar && (
        <div className="bg-white rounded-2xl p-6 border border-stone-200/90 shadow-2xs space-y-4">
          <div className="flex items-center gap-2 text-stone-900 font-bold text-base">
            <BookOpen className="w-5 h-5 text-emerald-600" />
            <span>Cấu Trúc Ngữ Pháp & Mẫu Câu Trọng Tâm</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
            {grammarPoints.map((gp, idx) => (
              <div
                key={idx}
                className="bg-stone-50/70 rounded-xl p-4 border border-stone-200/80 space-y-2"
              >
                <div className="text-sm font-bold text-stone-900 font-chinese flex items-center gap-2">
                  <span className="w-2 h-2 rounded-full bg-emerald-500" />
                  {gp.pattern}
                </div>
                <p className="text-xs text-stone-700 leading-relaxed">
                  {gp.explanation}
                </p>
                {gp.example && (
                  <div className="text-xs bg-white p-2.5 rounded-lg border border-stone-200/60 font-chinese text-stone-800">
                    <span className="text-stone-400 font-sans block text-[11px] mb-0.5">
                      Ví dụ ứng dụng:
                    </span>
                    {gp.example}
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {!hasGrammar && !hasSlang && !hasDisambiguations && (
        <div className="bg-white rounded-2xl p-8 border border-stone-200/90 text-center text-stone-500 text-sm">
          <p>Câu văn đơn giản, ngữ nghĩa trực tiếp và không có cấu trúc đa âm phức tạp.</p>
        </div>
      )}
    </div>
  );
};
