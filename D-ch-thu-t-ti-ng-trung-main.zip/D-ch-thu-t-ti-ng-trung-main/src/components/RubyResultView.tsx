import React, { useState } from 'react';
import { Volume2, Palette, Sparkles, HelpCircle } from 'lucide-react';
import { SentenceItem, Token } from '../types';
import { playMandarinTTS } from '../utils/audio';

interface RubyResultViewProps {
  sentences: SentenceItem[];
  onInspectWord: (word: string, contextSentence?: string) => void;
  audioRate: number;
}

// Tone color classification based on Pinyin vowels mark
function getToneColorClass(pinyin: string): string {
  if (/[āēīōūǖ]/.test(pinyin)) return 'text-red-700'; // Tone 1
  if (/[áéíóúǘ]/.test(pinyin)) return 'text-emerald-700'; // Tone 2
  if (/[ǎěǐǒǔǚ]/.test(pinyin)) return 'text-blue-700'; // Tone 3
  if (/[àèìòùǜ]/.test(pinyin)) return 'text-amber-700'; // Tone 4
  return 'text-stone-500'; // Neutral
}

export const RubyResultView: React.FC<RubyResultViewProps> = ({
  sentences,
  onInspectWord,
  audioRate,
}) => {
  const [colorizeTones, setColorizeTones] = useState<boolean>(true);
  const [playingIndex, setPlayingIndex] = useState<number | null>(null);

  const handlePlay = async (text: string, idx: number) => {
    setPlayingIndex(idx);
    try {
      await playMandarinTTS(text, audioRate);
    } finally {
      setPlayingIndex(null);
    }
  };

  return (
    <div className="space-y-6">
      {/* Control bar */}
      <div className="bg-white rounded-xl p-3 border border-stone-200 flex items-center justify-between text-xs">
        <div className="flex items-center gap-2 text-stone-600">
          <Sparkles className="w-4 h-4 text-amber-500" />
          <span>
            <strong>Chế độ Ruby Pinyin:</strong> Phiên âm nằm ngay phía trên từng chữ Hán. Nhấp vào từ để tra nghĩa & bộ thủ.
          </span>
        </div>
        <div className="flex items-center gap-3">
          <label className="inline-flex items-center gap-1.5 cursor-pointer font-medium text-stone-700">
            <input
              type="checkbox"
              checked={colorizeTones}
              onChange={(e) => setColorizeTones(e.target.checked)}
              className="rounded text-red-600 focus:ring-red-500 w-3.5 h-3.5"
            />
            <span>Màu sắc theo 4 thanh điệu</span>
          </label>
        </div>
      </div>

      {/* Tone Legend */}
      {colorizeTones && (
        <div className="flex items-center justify-center gap-4 text-xs bg-stone-100/70 py-2 px-4 rounded-xl border border-stone-200/80">
          <span className="font-semibold text-stone-500">Màu thanh điệu:</span>
          <span className="flex items-center gap-1 font-medium text-red-700">
            <span className="w-2 h-2 rounded-full bg-red-600" /> Thanh 1 (mā)
          </span>
          <span className="flex items-center gap-1 font-medium text-emerald-700">
            <span className="w-2 h-2 rounded-full bg-emerald-600" /> Thanh 2 (má)
          </span>
          <span className="flex items-center gap-1 font-medium text-blue-700">
            <span className="w-2 h-2 rounded-full bg-blue-600" /> Thanh 3 (mǎ)
          </span>
          <span className="flex items-center gap-1 font-medium text-amber-700">
            <span className="w-2 h-2 rounded-full bg-amber-600" /> Thanh 4 (mà)
          </span>
          <span className="flex items-center gap-1 font-medium text-stone-500">
            <span className="w-2 h-2 rounded-full bg-stone-400" /> Thanh nhẹ
          </span>
        </div>
      )}

      {/* Sentence Cards */}
      <div className="space-y-4">
        {sentences.map((sentence, idx) => (
          <div
            key={sentence.index}
            className="bg-white rounded-2xl p-6 border border-stone-200/90 shadow-2xs space-y-4"
          >
            {/* Top Info */}
            <div className="flex items-center justify-between border-b border-stone-100 pb-2">
              <div className="flex items-center gap-2">
                <span className="w-6 h-6 rounded-md bg-stone-100 text-stone-700 font-bold text-xs flex items-center justify-center">
                  {sentence.index}
                </span>
                {sentence.speaker && (
                  <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-red-100 text-red-800">
                    {sentence.speaker}
                  </span>
                )}
                <span className="text-xs text-stone-400">Nhấp vào từ để tra cứu</span>
              </div>

              <button
                type="button"
                onClick={() => handlePlay(sentence.chinese, sentence.index)}
                className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-lg text-xs font-medium transition-colors ${
                  playingIndex === sentence.index
                    ? 'bg-red-600 text-white'
                    : 'bg-stone-100 hover:bg-stone-200 text-stone-700'
                }`}
              >
                <Volume2 className="w-3.5 h-3.5" />
                <span>Phát âm</span>
              </button>
            </div>

            {/* Ruby Hanzi + Pinyin display */}
            <div className="pt-2 pb-3 flex flex-wrap items-baseline gap-x-2 gap-y-4 text-2xl sm:text-3xl font-chinese leading-relaxed">
              {sentence.tokens && sentence.tokens.length > 0 ? (
                sentence.tokens.map((tok, tIdx) => {
                  const toneClass = colorizeTones ? getToneColorClass(tok.pinyin) : 'text-red-700';

                  return (
                    <ruby
                      key={tIdx}
                      onClick={() => onInspectWord(tok.chinese, sentence.chinese)}
                      className="cursor-pointer group hover:bg-red-50/80 px-1 py-0.5 rounded-lg transition-all"
                      title={`${tok.chinese} [${tok.pinyin}] - ${tok.meaning}`}
                    >
                      <span className="text-stone-900 group-hover:text-red-700 transition-colors">
                        {tok.chinese}
                      </span>
                      <rt className={`${toneClass} font-sans text-xs sm:text-sm font-semibold tracking-normal`}>
                        {tok.pinyin}
                      </rt>
                    </ruby>
                  );
                })
              ) : (
                <div className="text-xl font-chinese">{sentence.chinese}</div>
              )}
            </div>

            {/* Vietnamese Translation */}
            <div className="pt-3 border-t border-stone-100 bg-stone-50/60 p-3.5 rounded-xl">
              <span className="text-xs font-bold text-stone-500 uppercase tracking-wider block mb-1">
                Dịch tiếng Việt:
              </span>
              <p className="text-base text-stone-900 font-medium">
                {sentence.vietnamese}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
