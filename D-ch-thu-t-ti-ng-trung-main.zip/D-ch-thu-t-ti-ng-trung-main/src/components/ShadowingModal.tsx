import React, { useState, useEffect, useRef } from 'react';
import {
  X,
  Volume2,
  VolumeX,
  Play,
  Pause,
  RotateCcw,
  SkipForward,
  Mic,
  MicOff,
  CheckCircle2,
  BookOpen,
  Sparkles,
  Eye,
  EyeOff,
  HelpCircle,
  Award,
  Layers,
  ArrowRight,
  RefreshCw,
  Flame,
} from 'lucide-react';
import { SentenceItem, TranslationResult } from '../types';
import { playMandarinTTS, stopAudio } from '../utils/audio';

interface ShadowingModalProps {
  isOpen: boolean;
  onClose: () => void;
  result: TranslationResult;
  audioRate: number;
}

type ShadowingMode = 'sentence' | 'paragraph' | 'blind';

export const ShadowingModal: React.FC<ShadowingModalProps> = ({
  isOpen,
  onClose,
  result,
  audioRate,
}) => {
  const [currentSentenceIndex, setCurrentSentenceIndex] = useState(0);
  const [mode, setMode] = useState<ShadowingMode>('sentence');
  const [repeatCount, setRepeatCount] = useState<number>(1);
  const [repeatCurrentCount, setRepeatCurrentCount] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [showHanzi, setShowHanzi] = useState<boolean>(true);
  const [showPinyin, setShowPinyin] = useState<boolean>(true);
  const [showVietnamese, setShowVietnamese] = useState<boolean>(true);

  // Recording states
  const [isRecording, setIsRecording] = useState<boolean>(false);
  const [audioBlobUrl, setAudioBlobUrl] = useState<string | null>(null);
  const mediaRecorderRef = useRef<MediaRecorder | null>(null);
  const audioChunksRef = useRef<Blob[]>([]);
  const [micError, setMicError] = useState<string | null>(null);

  // Stats
  const [completedSentences, setCompletedSentences] = useState<Set<number>>(new Set());
  const [difficultSentences, setDifficultSentences] = useState<Set<number>>(new Set());
  const [isFinishedSession, setIsFinishedSession] = useState<boolean>(false);

  const sentences = result.sentences || [];
  const currentSentence = sentences[currentSentenceIndex];

  useEffect(() => {
    if (!isOpen) {
      stopAudio();
      setIsPlaying(false);
      setIsRecording(false);
    }
  }, [isOpen]);

  if (!isOpen || !currentSentence) return null;

  const handlePlaySentenceAudio = async (text: string) => {
    if (isPlaying) {
      stopAudio();
      setIsPlaying(false);
      return;
    }

    setIsPlaying(true);
    try {
      await playMandarinTTS(text, audioRate);
      setCompletedSentences((prev) => new Set(prev).add(currentSentenceIndex));
    } finally {
      setIsPlaying(false);
    }
  };

  const handlePlayParagraphAudio = async () => {
    if (isPlaying) {
      stopAudio();
      setIsPlaying(false);
      return;
    }

    setIsPlaying(true);
    try {
      const fullText = sentences.map((s) => s.chinese).join(' ');
      await playMandarinTTS(fullText, audioRate);
      sentences.forEach((_, idx) => {
        setCompletedSentences((prev) => new Set(prev).add(idx));
      });
    } finally {
      setIsPlaying(false);
    }
  };

  // Microphone recording setup
  const startRecording = async () => {
    setMicError(null);
    audioChunksRef.current = [];
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      const mediaRecorder = new MediaRecorder(stream);
      mediaRecorderRef.current = mediaRecorder;

      mediaRecorder.ondataavailable = (e) => {
        if (e.data.size > 0) {
          audioChunksRef.current.push(e.data);
        }
      };

      mediaRecorder.onstop = () => {
        const audioBlob = new Blob(audioChunksRef.current, { type: 'audio/webm' });
        const url = URL.createObjectURL(audioBlob);
        setAudioBlobUrl(url);
        stream.getTracks().forEach((track) => track.stop());
      };

      mediaRecorder.start();
      setIsRecording(true);
    } catch (err: any) {
      console.error('Microphone error:', err);
      setMicError('Không thể truy cập microphone. Vui lòng kiểm tra quyền cấp phép trên trình duyệt.');
      setIsRecording(false);
    }
  };

  const stopRecording = () => {
    if (mediaRecorderRef.current && isRecording) {
      mediaRecorderRef.current.stop();
      setIsRecording(false);
    }
  };

  const toggleDifficulty = (idx: number) => {
    setDifficultSentences((prev) => {
      const next = new Set(prev);
      if (next.has(idx)) {
        next.delete(idx);
      } else {
        next.add(idx);
      }
      return next;
    });
  };

  const handleNextSentence = () => {
    stopAudio();
    setAudioBlobUrl(null);
    if (currentSentenceIndex < sentences.length - 1) {
      setCurrentSentenceIndex((prev) => prev + 1);
    } else {
      setIsFinishedSession(true);
    }
  };

  const progressPercent = Math.round((completedSentences.size / sentences.length) * 100);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="bg-white rounded-3xl max-w-3xl w-full max-h-[92vh] overflow-hidden shadow-2xl border border-stone-200 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="px-6 py-4 border-b border-stone-200 flex items-center justify-between bg-stone-50">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-xl bg-red-600 flex items-center justify-center text-white shadow-xs">
              <Sparkles className="w-5 h-5" />
            </div>
            <div>
              <h3 className="font-bold text-stone-900 text-base sm:text-lg flex items-center gap-2">
                <span>🎧 Luyện Shadowing Tiếng Trung</span>
              </h3>
              <p className="text-xs text-stone-500">
                Luyện phát âm chuẩn Mandarin &bull; Đối chiếu ngữ điệu & ghi âm
              </p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-stone-400 hover:text-stone-700 hover:bg-stone-200/60 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Progress bar */}
        <div className="bg-stone-100 px-6 py-2.5 border-b border-stone-200/80 flex flex-wrap items-center justify-between gap-3 text-xs">
          <div className="flex items-center gap-2">
            <span className="font-semibold text-stone-700">Tiến độ bài học:</span>
            <span className="font-bold text-red-700">
              {completedSentences.size} / {sentences.length} câu ({progressPercent}%)
            </span>
            <div className="w-24 sm:w-36 h-2 bg-stone-200 rounded-full overflow-hidden hidden sm:block">
              <div
                className="h-full bg-red-600 transition-all duration-300"
                style={{ width: `${progressPercent}%` }}
              />
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Mode selection */}
            <select
              value={mode}
              onChange={(e) => setMode(e.target.value as ShadowingMode)}
              className="bg-white border border-stone-200 rounded-lg px-2.5 py-1 text-xs font-semibold text-stone-700 focus:outline-hidden"
            >
              <option value="sentence">Chế độ: Từng câu</option>
              <option value="paragraph">Chế độ: Toàn đoạn</option>
              <option value="blind">Chế độ: Nghe mù</option>
            </select>
          </div>
        </div>

        {/* Modal Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1">
          {isFinishedSession ? (
            /* Finished Summary View */
            <div className="py-12 text-center space-y-6">
              <div className="w-20 h-20 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center mx-auto shadow-sm">
                <Award className="w-10 h-10" />
              </div>
              <div className="space-y-2">
                <h4 className="text-xl sm:text-2xl font-bold text-stone-900">
                  Chúc mừng bạn đã hoàn thành buổi luyện Shadowing!
                </h4>
                <p className="text-sm text-stone-600 max-w-md mx-auto">
                  Bạn đã luyện tập thành công toàn bộ đoạn văn, rèn luyện phát âm thanh điệu và ngữ điệu chuẩn xác.
                </p>
              </div>

              <div className="bg-stone-50 p-4 rounded-2xl border border-stone-200 max-w-sm mx-auto grid grid-cols-2 gap-4 text-center text-xs">
                <div>
                  <span className="text-stone-400 block mb-1">Số câu đã luyện</span>
                  <strong className="text-stone-900 text-lg">{sentences.length} câu</strong>
                </div>
                <div>
                  <span className="text-stone-400 block mb-1">Câu cần ôn lại</span>
                  <strong className="text-red-600 text-lg">{difficultSentences.size} câu</strong>
                </div>
              </div>

              <div className="flex items-center justify-center gap-3 pt-4">
                <button
                  type="button"
                  onClick={() => {
                    setIsFinishedSession(false);
                    setCurrentSentenceIndex(0);
                  }}
                  className="px-5 py-2.5 rounded-xl bg-stone-100 hover:bg-stone-200 font-semibold text-xs text-stone-800 transition-colors"
                >
                  Luyện lại từ đầu
                </button>
                <button
                  type="button"
                  onClick={onClose}
                  className="px-6 py-2.5 rounded-xl bg-red-600 hover:bg-red-700 font-semibold text-xs text-white shadow-sm transition-colors"
                >
                  Hoàn thành & Quay lại
                </button>
              </div>
            </div>
          ) : mode === 'paragraph' ? (
            /* Paragraph Mode */
            <div className="space-y-6">
              <div className="bg-gradient-to-br from-stone-50 to-red-50/40 p-6 rounded-2xl border border-stone-200/90 space-y-4">
                <div className="flex items-center justify-between border-b border-stone-200/70 pb-3">
                  <span className="text-xs font-bold uppercase tracking-wider text-red-700">
                    Luyện Shadowing Toàn Đoạn
                  </span>
                  <button
                    type="button"
                    onClick={handlePlayParagraphAudio}
                    className={`inline-flex items-center gap-2 px-4 py-2 rounded-xl text-xs font-semibold transition-all shadow-xs ${
                      isPlaying ? 'bg-red-600 text-white animate-pulse' : 'bg-red-600 hover:bg-red-700 text-white'
                    }`}
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                    <span>{isPlaying ? 'Đang phát toàn đoạn...' : 'Nghe toàn đoạn văn'}</span>
                  </button>
                </div>

                <div className="space-y-4">
                  {sentences.map((s, sIdx) => (
                    <div key={sIdx} className="space-y-1.5 p-3 rounded-xl bg-white/80 border border-stone-200/60">
                      <div className="text-xl font-chinese font-semibold text-stone-900 leading-relaxed">
                        {s.chinese}
                      </div>
                      <div className="text-sm font-sans font-medium text-red-700">{s.pinyin}</div>
                      <div className="text-sm text-stone-800">{s.vietnamese}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          ) : (
            /* Sentence Mode & Blind Mode */
            <div className="space-y-6">
              {/* Sentence Navigation Header */}
              <div className="flex items-center justify-between text-xs font-semibold text-stone-500">
                <span>
                  Câu {currentSentenceIndex + 1} / {sentences.length}
                </span>
                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={() => toggleDifficulty(currentSentenceIndex)}
                    className={`px-2.5 py-1 rounded-lg border transition-colors ${
                      difficultSentences.has(currentSentenceIndex)
                        ? 'bg-amber-100 text-amber-900 border-amber-300 font-bold'
                        : 'bg-white text-stone-600 border-stone-200 hover:bg-stone-50'
                    }`}
                  >
                    {difficultSentences.has(currentSentenceIndex) ? '⭐ Đã đánh dấu khó' : '☆ Đánh dấu khó'}
                  </button>
                </div>
              </div>

              {/* Main Sentence Card */}
              <div className="bg-gradient-to-br from-stone-50 to-amber-50/20 p-6 rounded-2xl border border-stone-200/90 shadow-2xs space-y-6">
                {/* Visibility toggles */}
                <div className="flex items-center justify-end gap-3 text-xs text-stone-500 pb-2 border-b border-stone-200/60">
                  <button
                    type="button"
                    onClick={() => setShowHanzi(!showHanzi)}
                    className={`inline-flex items-center gap-1 px-2 py-1 rounded transition-colors ${
                      showHanzi ? 'bg-stone-200 text-stone-800' : 'bg-stone-100 text-stone-400'
                    }`}
                  >
                    {showHanzi ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                    <span>Chữ Hán</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowPinyin(!showPinyin)}
                    className={`inline-flex items-center gap-1 px-2 py-1 rounded transition-colors ${
                      showPinyin ? 'bg-stone-200 text-stone-800' : 'bg-stone-100 text-stone-400'
                    }`}
                  >
                    {showPinyin ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                    <span>Pinyin</span>
                  </button>

                  <button
                    type="button"
                    onClick={() => setShowVietnamese(!showVietnamese)}
                    className={`inline-flex items-center gap-1 px-2 py-1 rounded transition-colors ${
                      showVietnamese ? 'bg-stone-200 text-stone-800' : 'bg-stone-100 text-stone-400'
                    }`}
                  >
                    {showVietnamese ? <Eye className="w-3.5 h-3.5" /> : <EyeOff className="w-3.5 h-3.5" />}
                    <span>Tiếng Việt</span>
                  </button>
                </div>

                {/* Content Display */}
                <div className="space-y-4 text-center sm:text-left">
                  {/* Chinese */}
                  {showHanzi && mode !== 'blind' && (
                    <div>
                      <span className="text-xs font-bold uppercase tracking-wider text-stone-400 block mb-1">
                        Tiếng Trung
                      </span>
                      <div className="text-2xl sm:text-3xl font-chinese font-bold text-stone-900 tracking-wide leading-relaxed">
                        {currentSentence.chinese}
                      </div>
                    </div>
                  )}

                  {/* Pinyin */}
                  {showPinyin && mode !== 'blind' && (
                    <div>
                      <span className="text-xs font-bold uppercase tracking-wider text-stone-400 block mb-1">
                        Pinyin chuẩn
                      </span>
                      <div className="text-lg sm:text-xl font-sans font-semibold text-red-700 tracking-normal">
                        {currentSentence.pinyin}
                      </div>
                    </div>
                  )}

                  {/* Vietnamese */}
                  {showVietnamese && (
                    <div>
                      <span className="text-xs font-bold uppercase tracking-wider text-stone-400 block mb-1">
                        Nghĩa tiếng Việt
                      </span>
                      <div className="text-base sm:text-lg text-stone-800 font-medium leading-relaxed bg-white/70 p-3 rounded-xl border border-stone-200/60 inline-block w-full text-left">
                        {currentSentence.vietnamese}
                      </div>
                    </div>
                  )}

                  {mode === 'blind' && (
                    <div className="bg-amber-50 border border-amber-200 p-4 rounded-xl text-center text-xs text-amber-900 space-y-1">
                      <p className="font-semibold">Chế độ nghe mù (Blind Mode đang bật)</p>
                      <p>Hãy tập trung nghe audio mẫu trước, sau đó bấm nút "Hiện chữ" nếu cần đối chiếu.</p>
                      <button
                        type="button"
                        onClick={() => {
                          setMode('sentence');
                        }}
                        className="mt-2 px-3 py-1 bg-amber-600 text-white font-semibold rounded-lg text-xs"
                      >
                        Hiện chữ ngay
                      </button>
                    </div>
                  )}
                </div>

                {/* Audio Control Bar */}
                <div className="pt-4 border-t border-stone-200/70 flex flex-wrap items-center justify-between gap-3">
                  <button
                    type="button"
                    onClick={() => handlePlaySentenceAudio(currentSentence.chinese)}
                    className={`inline-flex items-center gap-2 px-5 py-2.5 rounded-xl font-semibold text-sm transition-all shadow-xs ${
                      isPlaying
                        ? 'bg-red-600 text-white animate-pulse'
                        : 'bg-red-600 hover:bg-red-700 text-white shadow-red-600/20'
                    }`}
                  >
                    {isPlaying ? <Pause className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
                    <span>{isPlaying ? 'Đang phát...' : '🎧 Nghe mẫu câu'}</span>
                  </button>

                  <div className="flex items-center gap-2">
                    {/* Record button */}
                    {!isRecording ? (
                      <button
                        type="button"
                        onClick={startRecording}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-stone-100 hover:bg-stone-200 text-stone-800 transition-colors border border-stone-200"
                        title="Bắt đầu ghi âm giọng đọc của bạn để so sánh"
                      >
                        <Mic className="w-4 h-4 text-red-600" />
                        <span>Ghi âm giọng nói</span>
                      </button>
                    ) : (
                      <button
                        type="button"
                        onClick={stopRecording}
                        className="inline-flex items-center gap-1.5 px-3.5 py-2 rounded-xl text-xs font-semibold bg-red-600 text-white animate-pulse shadow-sm"
                        title="Dừng ghi âm"
                      >
                        <MicOff className="w-4 h-4" />
                        <span>Đang ghi âm (Bấm để dừng)</span>
                      </button>
                    )}
                  </div>
                </div>

                {/* Microphone Error or Recorded playback */}
                {micError && <p className="text-xs text-red-600 font-medium">{micError}</p>}

                {audioBlobUrl && (
                  <div className="bg-stone-100 p-3 rounded-xl border border-stone-200 flex items-center justify-between text-xs">
                    <span className="font-semibold text-stone-700">Bản ghi âm của bạn:</span>
                    <audio controls src={audioBlobUrl} className="h-8 max-w-[220px]" />
                  </div>
                )}
              </div>

              {/* Tips for Shadowing & Tone Sandhi */}
              <div className="bg-stone-50 p-4 rounded-2xl border border-stone-200/80 space-y-2 text-xs text-stone-700">
                <span className="font-bold text-stone-900 block flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                  Mẹo Shadowing chuyên sâu:
                </span>
                <ul className="list-disc list-inside space-y-1 pl-1 text-stone-600">
                  <li>Lặp lại gần như đồng thời theo audio (đuổi theo giọng người bản xứ).</li>
                  <li>Chú ý biến điệu thanh 3 (2 thanh 3 liền nhau đọc thành 2-2 hoặc 2-3).</li>
                  <li>Giữ nhịp điệu và ngắt nghỉ tự nhiên theo cụm từ.</li>
                </ul>
              </div>

              {/* Bottom Action Footer */}
              <div className="flex items-center justify-between pt-2">
                <button
                  type="button"
                  onClick={() => {
                    if (currentSentenceIndex > 0) {
                      setCurrentSentenceIndex((prev) => prev - 1);
                      setAudioBlobUrl(null);
                    }
                  }}
                  disabled={currentSentenceIndex === 0}
                  className="px-4 py-2 rounded-xl border border-stone-200 text-xs font-semibold text-stone-700 hover:bg-stone-100 disabled:opacity-40 disabled:cursor-not-allowed"
                >
                  Câu trước
                </button>

                <button
                  type="button"
                  onClick={handleNextSentence}
                  className="inline-flex items-center gap-2 px-6 py-2.5 rounded-xl bg-stone-900 hover:bg-stone-800 text-white font-semibold text-xs transition-colors shadow-xs"
                >
                  <span>{currentSentenceIndex < sentences.length - 1 ? 'Câu tiếp theo' : 'Hoàn thành bài học'}</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
