import React from 'react';
import { Volume2, User, UserCheck } from 'lucide-react';
import { SentenceItem } from '../types';
import { playMandarinTTS } from '../utils/audio';

interface DialogueViewProps {
  sentences: SentenceItem[];
  onInspectWord: (word: string) => void;
  audioRate: number;
}

export const DialogueView: React.FC<DialogueViewProps> = ({
  sentences,
  onInspectWord,
  audioRate,
}) => {
  return (
    <div className="bg-white rounded-2xl p-6 border border-stone-200/90 shadow-2xs space-y-6">
      <div className="border-b border-stone-100 pb-3 flex items-center justify-between">
        <h3 className="font-bold text-stone-900 text-sm flex items-center gap-2">
          <span>Chế độ Hội Thoại Đối Chiếu</span>
          <span className="text-xs font-normal text-stone-500">
            Giữ nguyên thứ tự người nói và định dạng đàm thoại
          </span>
        </h3>
      </div>

      <div className="space-y-4">
        {sentences.map((item, idx) => {
          const isEven = idx % 2 === 0;
          const speakerName = item.speaker || `Người nói ${idx + 1}`;

          return (
            <div
              key={item.index}
              className={`flex items-start gap-3 ${
                isEven ? 'flex-row' : 'flex-row-reverse'
              }`}
            >
              {/* Speaker Avatar */}
              <div
                className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-sm shrink-0 shadow-2xs ${
                  isEven
                    ? 'bg-red-600 text-white'
                    : 'bg-stone-800 text-white'
                }`}
                title={speakerName}
              >
                {speakerName.slice(0, 1)}
              </div>

              {/* Chat Bubble */}
              <div
                className={`max-w-[85%] rounded-2xl p-4 shadow-2xs border ${
                  isEven
                    ? 'bg-stone-50/80 border-stone-200 rounded-tl-xs'
                    : 'bg-red-50/50 border-red-200/80 rounded-tr-xs'
                }`}
              >
                <div className="flex items-center justify-between gap-3 mb-1.5">
                  <span className="font-bold text-xs text-stone-800">
                    {speakerName}
                  </span>
                  <button
                    type="button"
                    onClick={() => playMandarinTTS(item.chinese, audioRate)}
                    className="p-1 text-stone-400 hover:text-stone-800 transition-colors rounded"
                    title="Nghe phát âm"
                  >
                    <Volume2 className="w-3.5 h-3.5" />
                  </button>
                </div>

                {/* Chinese */}
                <div className="text-lg font-chinese font-semibold text-stone-900 leading-snug">
                  {item.tokens && item.tokens.length > 0 ? (
                    item.tokens.map((tok, tIdx) => (
                      <span
                        key={tIdx}
                        onClick={() => onInspectWord(tok.chinese)}
                        className="cursor-pointer hover:text-red-700 transition-colors"
                        title={`${tok.pinyin}: ${tok.meaning}`}
                      >
                        {tok.chinese}
                      </span>
                    ))
                  ) : (
                    <span>{item.chinese}</span>
                  )}
                </div>

                {/* Pinyin */}
                <div className="text-sm font-sans font-medium text-red-700 mt-1">
                  {item.pinyin}
                </div>

                {/* Vietnamese */}
                <div className="text-sm text-stone-800 mt-2 pt-2 border-t border-stone-200/60 font-medium">
                  {item.vietnamese}
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};
