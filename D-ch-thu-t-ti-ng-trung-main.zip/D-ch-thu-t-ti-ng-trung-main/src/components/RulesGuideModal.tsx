import React from 'react';
import { X, CheckCircle2, ShieldCheck, BookOpen, AlertCircle } from 'lucide-react';

interface RulesGuideModalProps {
  isOpen: boolean;
  onClose: () => void;
}

export const RulesGuideModal: React.FC<RulesGuideModalProps> = ({ isOpen, onClose }) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/50 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="bg-white rounded-3xl max-w-2xl w-full max-h-[88vh] overflow-hidden shadow-2xl border border-stone-200 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Header */}
        <div className="p-5 border-b border-stone-100 flex items-center justify-between bg-stone-50/80">
          <div className="flex items-center gap-2">
            <ShieldCheck className="w-5 h-5 text-red-600" />
            <h3 className="font-bold text-stone-900 text-base">
              Bộ Quy Tắc Tiêu Chuẩn Dịch Tiếng Trung & Pinyin
            </h3>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 rounded-lg"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content */}
        <div className="p-6 overflow-y-auto space-y-6 text-sm text-stone-800">
          {/* Section 1 */}
          <div className="space-y-2">
            <h4 className="font-bold text-red-800 text-sm flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-red-100 text-red-800 flex items-center justify-center text-xs">
                1
              </span>
              Quy tắc dịch bắt buộc
            </h4>
            <div className="bg-stone-50 p-3.5 rounded-xl border border-stone-200/80 text-xs space-y-1.5 text-stone-700">
              <p>
                <strong>Thứ tự xử lý:</strong> Tiếng Trung gốc &rarr; Pinyin &rarr; Tiếng Việt &rarr; Giải thích (khi được yêu cầu hoặc khi có điểm dễ nhầm lẫn).
              </p>
              <p>
                <strong>Tiếng Trung gốc:</strong> Giữ nguyên chữ Hán, dấu câu và cách chia câu của bản gốc.
              </p>
              <p>
                <strong>Pinyin:</strong> Phiên âm chuẩn Hanyu Pinyin, có đầy đủ dấu thanh, đúng âm tiết và quy tắc biến điệu khi phù hợp.
              </p>
              <p>
                <strong>Tiếng Việt:</strong> Dịch chính xác ý nghĩa, tự nhiên, dễ hiểu và phù hợp với ngữ cảnh.
              </p>
            </div>
          </div>

          {/* Section 2 */}
          <div className="space-y-2">
            <h4 className="font-bold text-red-800 text-sm flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-red-100 text-red-800 flex items-center justify-center text-xs">
                2
              </span>
              Định dạng đầu ra chuẩn
            </h4>
            <div className="bg-stone-50 p-3.5 rounded-xl border border-stone-200/80 text-xs space-y-2 text-stone-700 font-mono">
              <div className="bg-white p-2.5 rounded-lg border border-stone-200 text-stone-800 font-sans">
                <p className="font-bold text-stone-900 mb-1">Mẫu câu đơn hoặc đoạn văn:</p>
                <p className="text-red-700 font-chinese font-semibold">Tiếng Trung: 你好，很高兴认识你。</p>
                <p className="text-amber-700 font-medium">Pinyin: Nǐ hǎo, hěn gāoxìng rènshi nǐ.</p>
                <p className="text-emerald-700 font-medium">Tiếng Việt: Xin chào, rất vui được làm quen với bạn.</p>
              </div>
              <p className="font-sans text-[11px] text-stone-500">
                Nếu văn bản có nhiều câu, hệ thống tự động đánh số từng câu [1], [2] và trình bày riêng từng phần tương ứng để dễ đối chiếu.
              </p>
            </div>
          </div>

          {/* Section 3 */}
          <div className="space-y-2">
            <h4 className="font-bold text-red-800 text-sm flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-red-100 text-red-800 flex items-center justify-center text-xs">
                3
              </span>
              Quy tắc phiên âm Pinyin
            </h4>
            <ul className="list-disc list-inside space-y-1 text-xs text-stone-700 pl-1">
              <li>Luôn sử dụng Pinyin chuẩn Hanyu Pinyin có dấu thanh: <code>mā, má, mǎ, mà</code>. Tuyệt đối không dùng không dấu.</li>
              <li>Tách từ hợp lý theo cụm ngữ pháp, giữ nguyên dấu câu.</li>
              <li>Tuân thủ quy tắc thanh nhẹ, biến điệu của thanh 3 (2 thanh 3 đi liền &rarr; 2-3).</li>
              <li>Biến điệu của <strong>不 (bù/bú)</strong> và <strong>一 (yī/yí/yì)</strong> theo đúng từ đi kèm.</li>
              <li>Phân biệt chữ Hán đa âm (多音字: 得, 行, 了, 着, 地...) chuẩn ngữ cảnh.</li>
            </ul>
          </div>

          {/* Section 4 */}
          <div className="space-y-2">
            <h4 className="font-bold text-red-800 text-sm flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-red-100 text-red-800 flex items-center justify-center text-xs">
                4
              </span>
              Quy tắc dịch tiếng Việt
            </h4>
            <ul className="list-disc list-inside space-y-1 text-xs text-stone-700 pl-1">
              <li>Dịch tự nhiên như người Việt sử dụng, không dịch thô ngữ pháp Hán.</li>
              <li>Giữ nguyên sắc thái: lịch sự, thân mật, trang trọng, hài hước, tức giận...</li>
              <li>Thành ngữ (成语), tiếng lóng, từ mạng: giải thích nghĩa thực tế thay vì dịch thô chữ-đối-chữ gây hiểu lầm.</li>
            </ul>
          </div>

          {/* Section 5 & 6 */}
          <div className="space-y-2">
            <h4 className="font-bold text-red-800 text-sm flex items-center gap-2">
              <span className="w-5 h-5 rounded-full bg-red-100 text-red-800 flex items-center justify-center text-xs">
                5
              </span>
              Chế độ làm việc & Tự động nhận diện
            </h4>
            <div className="text-xs text-stone-700 space-y-1 bg-stone-50 p-3.5 rounded-xl border border-stone-200/80">
              <p>&bull; <strong>Chữ Phồn thể:</strong> Giữ nguyên chữ Hán phồn thể, phiên âm theo Mandarin và dịch tiếng Việt.</p>
              <p>&bull; <strong>Ảnh (OCR):</strong> Nhận diện chữ Hán rồi dịch, đánh dấu chữ không chắc chắn.</p>
              <p>&bull; <strong>Hội thoại:</strong> Giữ nguyên thứ tự người nói và định dạng hội thoại.</p>
              <p>&bull; <strong>Nguyên tắc:</strong> Không tự ý tóm tắt hoặc thêm ý, không bịa chữ Hán, không nhầm Pinyin với tiếng Việt.</p>
            </div>
          </div>
        </div>

        {/* Footer */}
        <div className="p-4 border-t border-stone-100 bg-stone-50/60 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="px-5 py-2 rounded-xl bg-stone-900 text-white font-medium text-xs hover:bg-stone-800 transition-colors"
          >
            Đã hiểu
          </button>
        </div>
      </div>
    </div>
  );
};
