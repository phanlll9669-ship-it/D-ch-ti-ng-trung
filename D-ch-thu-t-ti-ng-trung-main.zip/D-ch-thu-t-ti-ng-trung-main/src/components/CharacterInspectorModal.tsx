import React, { useEffect, useState } from 'react';
import {
  X,
  Volume2,
  BookmarkPlus,
  BookmarkCheck,
  Loader2,
  BookOpen,
  Layers,
  Sparkles,
  ExternalLink,
} from 'lucide-react';
import { CharDetail, SavedWord } from '../types';
import { playMandarinTTS } from '../utils/audio';

interface CharacterInspectorModalProps {
  word: string | null;
  contextSentence?: string;
  onClose: () => void;
  onSaveWord: (word: SavedWord) => void;
  isWordSaved: (chinese: string) => boolean;
  audioRate: number;
}

export const CharacterInspectorModal: React.FC<CharacterInspectorModalProps> = ({
  word,
  contextSentence,
  onClose,
  onSaveWord,
  isWordSaved,
  audioRate,
}) => {
  const [loading, setLoading] = useState<boolean>(false);
  const [data, setData] = useState<CharDetail | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!word) return;

    let isMounted = true;
    setLoading(true);
    setError(null);

    fetch('/api/inspect-char', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ character: word, contextSentence }),
    })
      .then(async (res) => {
        const contentType = res.headers.get('content-type') || '';
        if (!res.ok || !contentType.includes('application/json')) {
          let errMsg = 'Không thể tra cứu chữ này';
          if (contentType.includes('application/json')) {
            const errData = await res.json().catch(() => ({}));
            errMsg = errData.error || errMsg;
          }
          throw new Error(errMsg);
        }
        return res.json();
      })
      .then((resData) => {
        if (isMounted) {
          setData(resData);
          setLoading(false);
        }
      })
      .catch((err) => {
        if (isMounted) {
          setError(err.message || 'Lỗi tra cứu');
          setLoading(false);
        }
      });

    return () => {
      isMounted = false;
    };
  }, [word, contextSentence]);

  if (!word) return null;

  const saved = isWordSaved(word);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-stone-900/60 backdrop-blur-xs animate-in fade-in duration-200">
      <div
        className="bg-white rounded-3xl max-w-xl w-full max-h-[90vh] overflow-hidden shadow-2xl border border-stone-200 flex flex-col"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Top Header */}
        <div className="px-6 py-4 border-b border-stone-100 flex items-center justify-between bg-stone-50/60">
          <div className="flex items-center gap-2">
            <span className="text-xs font-bold uppercase tracking-wider text-red-600 bg-red-100 px-2 py-0.5 rounded-md">
              Tra Cứu Chi Tiết
            </span>
            <span className="text-xs text-stone-500">Chữ Hán & Từ Vựng</span>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 text-stone-400 hover:text-stone-700 hover:bg-stone-100 rounded-full transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Content Body */}
        <div className="p-6 overflow-y-auto space-y-6">
          {loading ? (
            <div className="py-16 flex flex-col items-center justify-center space-y-3">
              <Loader2 className="w-8 h-8 text-red-600 animate-spin" />
              <p className="text-sm font-medium text-stone-600">
                Đang tra cứu từ điển chữ Hán "{word}"...
              </p>
            </div>
          ) : error ? (
            <div className="py-12 text-center text-stone-500 text-sm">
              <p className="text-red-600 font-medium mb-1">Đã có lỗi xảy ra</p>
              <p>{error}</p>
            </div>
          ) : data ? (
            <>
              {/* Giant Character & Essential Card */}
              <div className="flex flex-col sm:flex-row items-center sm:items-start gap-6 bg-gradient-to-br from-stone-50 to-red-50/30 p-6 rounded-2xl border border-stone-200/80">
                {/* Character Block */}
                <div className="relative group shrink-0">
                  <div className="w-24 h-24 sm:w-28 sm:h-28 rounded-2xl bg-white border border-stone-200 shadow-sm flex items-center justify-center font-chinese text-5xl sm:text-6xl font-bold text-stone-900 select-all">
                    {data.simplified}
                  </div>
                  <button
                    onClick={() => playMandarinTTS(data.simplified, audioRate)}
                    className="absolute -bottom-2 -right-2 p-2 rounded-full bg-red-600 text-white shadow-md hover:bg-red-700 transition-colors"
                    title="Nghe phát âm"
                  >
                    <Volume2 className="w-4 h-4" />
                  </button>
                </div>

                {/* Info Block */}
                <div className="space-y-2 text-center sm:text-left flex-1">
                  <div className="flex items-center justify-center sm:justify-start gap-3 flex-wrap">
                    <span className="text-xl sm:text-2xl font-bold text-red-700 font-sans">
                      {data.pinyin}
                    </span>
                    <span className="px-2.5 py-0.5 rounded-full text-xs font-semibold bg-amber-100 text-amber-900 border border-amber-200">
                      Hán Việt: {data.hanViet}
                    </span>
                    {data.hskLevel && (
                      <span className="px-2 py-0.5 rounded-full text-xs font-semibold bg-emerald-100 text-emerald-800 border border-emerald-200">
                        {data.hskLevel}
                      </span>
                    )}
                  </div>

                  <p className="text-base text-stone-900 font-semibold pt-1">
                    {data.primaryMeaning}
                  </p>

                  <div className="flex items-center justify-center sm:justify-start gap-4 text-xs text-stone-500 pt-1">
                    <span>
                      Bộ thủ: <strong className="font-chinese text-stone-800">{data.radical}</strong>
                    </span>
                    <span>&bull;</span>
                    <span>
                      Số nét: <strong className="text-stone-800">{data.strokeCount}</strong>
                    </span>
                    {data.traditional && data.traditional !== data.simplified && (
                      <>
                        <span>&bull;</span>
                        <span>
                          Phồn thể: <strong className="font-chinese text-stone-800">{data.traditional}</strong>
                        </span>
                      </>
                    )}
                  </div>

                  {/* Save Word Button */}
                  <div className="pt-2">
                    <button
                      type="button"
                      onClick={() =>
                        onSaveWord({
                          id: `${data.simplified}-${Date.now()}`,
                          chinese: data.simplified,
                          pinyin: data.pinyin,
                          hanViet: data.hanViet,
                          meaning: data.primaryMeaning,
                          partOfSpeech: data.partOfSpeech,
                          hskLevel: data.hskLevel,
                          createdAt: Date.now(),
                        })
                      }
                      className={`inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold transition-colors ${
                        saved
                          ? 'bg-amber-100 text-amber-900 border border-amber-200'
                          : 'bg-stone-900 hover:bg-stone-800 text-white shadow-2xs'
                      }`}
                    >
                      {saved ? (
                        <>
                          <BookmarkCheck className="w-3.5 h-3.5 text-amber-700" />
                          <span>Đã lưu vào Sổ từ vựng</span>
                        </>
                      ) : (
                        <>
                          <BookmarkPlus className="w-3.5 h-3.5" />
                          <span>Lưu vào Sổ từ vựng</span>
                        </>
                      )}
                    </button>
                  </div>
                </div>
              </div>

              {/* Polyphone readings if any */}
              {data.polyphoneReadings && data.polyphoneReadings.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider flex items-center gap-1.5">
                    <Sparkles className="w-3.5 h-3.5 text-amber-600" />
                    Các Âm Đa Âm (多音字):
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {data.polyphoneReadings.map((poly, pIdx) => (
                      <div
                        key={pIdx}
                        className="bg-amber-50/50 p-2.5 rounded-xl border border-amber-200/60"
                      >
                        <div className="font-bold text-red-700 font-sans text-sm mb-0.5">
                          {poly.reading}
                        </div>
                        <div className="text-stone-800">{poly.meaning}</div>
                        {poly.sampleWord && (
                          <div className="text-stone-500 font-chinese text-[11px] mt-1">
                            Ví dụ: {poly.sampleWord}
                          </div>
                        )}
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Compound words */}
              {data.compoundWords && data.compoundWords.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider">
                    Từ Ghép Thông Dụng:
                  </h4>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    {data.compoundWords.map((cw, cIdx) => (
                      <div
                        key={cIdx}
                        className="bg-stone-50 p-2.5 rounded-xl border border-stone-200 flex items-center justify-between"
                      >
                        <div>
                          <div className="flex items-center gap-2">
                            <span className="font-chinese font-bold text-stone-900 text-sm">
                              {cw.word}
                            </span>
                            <span className="text-red-700 font-sans font-medium">
                              {cw.pinyin}
                            </span>
                          </div>
                          <div className="text-stone-600 text-[11px] mt-0.5">
                            {cw.meaning}
                          </div>
                        </div>
                        <button
                          type="button"
                          onClick={() => playMandarinTTS(cw.word, audioRate)}
                          className="p-1 text-stone-400 hover:text-stone-700"
                        >
                          <Volume2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Examples */}
              {data.examples && data.examples.length > 0 && (
                <div className="space-y-2">
                  <h4 className="text-xs font-bold text-stone-700 uppercase tracking-wider">
                    Câu Ví Dụ Minh Họa:
                  </h4>
                  <div className="space-y-2 text-xs">
                    {data.examples.map((ex, eIdx) => (
                      <div
                        key={eIdx}
                        className="bg-stone-50/70 p-3 rounded-xl border border-stone-200/80 space-y-1"
                      >
                        <div className="flex items-center justify-between">
                          <span className="font-chinese font-semibold text-stone-900 text-sm">
                            {ex.chinese}
                          </span>
                          <button
                            type="button"
                            onClick={() => playMandarinTTS(ex.chinese, audioRate)}
                            className="p-1 text-stone-400 hover:text-stone-700"
                          >
                            <Volume2 className="w-3.5 h-3.5" />
                          </button>
                        </div>
                        <div className="text-red-700 font-sans">{ex.pinyin}</div>
                        <div className="text-stone-700 font-medium">{ex.vietnamese}</div>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          ) : null}
        </div>
      </div>
    </div>
  );
};
