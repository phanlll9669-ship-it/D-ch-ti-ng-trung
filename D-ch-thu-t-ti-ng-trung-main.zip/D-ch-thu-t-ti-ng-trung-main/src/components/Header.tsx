import React from 'react';
import { BookOpen, History, HelpCircle, Bookmark, Sparkles, Volume2 } from 'lucide-react';

interface HeaderProps {
  onOpenRules: () => void;
  onOpenHistory: () => void;
  onOpenSavedWords: () => void;
  savedWordsCount: number;
  historyCount: number;
}

export const Header: React.FC<HeaderProps> = ({
  onOpenRules,
  onOpenHistory,
  onOpenSavedWords,
  savedWordsCount,
  historyCount,
}) => {
  return (
    <header className="border-b border-stone-200 bg-white/95 backdrop-blur-md sticky top-0 z-30 shadow-xs">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        {/* Brand / Logo */}
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-red-600 to-amber-700 flex items-center justify-center text-white shadow-sm ring-2 ring-red-100">
            <span className="font-calligraphy text-2xl leading-none select-none">华</span>
          </div>
          <div>
            <div className="flex items-center gap-2">
              <h1 className="font-bold text-stone-900 tracking-tight text-lg sm:text-xl font-sans">
                Trợ Lý Dịch Tiếng Trung
              </h1>
              <span className="text-xs px-2 py-0.5 rounded-full font-semibold bg-red-100 text-red-800 border border-red-200/60 hidden sm:inline-flex items-center gap-1">
                <span className="font-chinese text-sm">拼音</span> Pinyin chuẩn
              </span>
            </div>
            <p className="text-xs text-stone-500 hidden md:block">
              Hán Tự &bull; Pinyin có dấu thanh &bull; Tiếng Việt tự nhiên theo ngữ cảnh
            </p>
          </div>
        </div>

        {/* Action Navigation */}
        <div className="flex items-center gap-1.5 sm:gap-2">
          {/* Rules Guide Button */}
          <button
            onClick={onOpenRules}
            type="button"
            className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium text-stone-700 hover:text-stone-900 hover:bg-stone-100 transition-colors"
            title="Xem quy tắc dịch và phiên âm chuẩn"
          >
            <HelpCircle className="w-4 h-4 text-stone-500" />
            <span className="hidden sm:inline">Quy tắc chuẩn</span>
          </button>

          {/* Saved Vocabulary */}
          <button
            onClick={onOpenSavedWords}
            type="button"
            className="relative inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium text-stone-700 hover:text-stone-900 hover:bg-stone-100 transition-colors"
            title="Sổ từ vựng đã lưu"
          >
            <Bookmark className="w-4 h-4 text-amber-600" />
            <span className="hidden sm:inline">Sổ từ vựng</span>
            {savedWordsCount > 0 && (
              <span className="ml-0.5 px-1.5 py-0.2 rounded-full text-[11px] font-bold bg-amber-500 text-white">
                {savedWordsCount}
              </span>
            )}
          </button>

          {/* History */}
          <button
            onClick={onOpenHistory}
            type="button"
            className="relative inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs sm:text-sm font-medium text-stone-700 hover:text-stone-900 hover:bg-stone-100 transition-colors"
            title="Lịch sử tra dịch"
          >
            <History className="w-4 h-4 text-stone-500" />
            <span className="hidden sm:inline">Lịch sử</span>
            {historyCount > 0 && (
              <span className="ml-0.5 px-1.5 py-0.2 rounded-full text-[11px] font-bold bg-stone-200 text-stone-700">
                {historyCount}
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
};
