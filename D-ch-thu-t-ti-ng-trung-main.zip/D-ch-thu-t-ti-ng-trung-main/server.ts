import express, { Request, Response } from 'express';
import { GoogleGenAI, Type } from '@google/genai';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = process.env.PORT || 3000;

app.use(express.json({ limit: '30mb' }));

// Initialize Gemini SDK with telemetry header
const ai = new GoogleGenAI({
  apiKey: process.env.GEMINI_API_KEY,
  httpOptions: {
    headers: {
      'User-Agent': 'aistudio-build',
    },
  },
});

import { jsonrepair } from 'jsonrepair';

// Candidate models in order of priority (using gemini-3.1-flash-lite as primary to avoid quota limits)
const CANDIDATE_MODELS = ['gemini-3.1-flash-lite', 'gemini-3.8-flash'];

async function callGeminiWithFallback<T>(
  callFn: (modelName: string) => Promise<T>
): Promise<T> {
  let lastError: any = null;
  for (const model of CANDIDATE_MODELS) {
    try {
      return await callFn(model);
    } catch (err: any) {
      console.warn(`[Gemini Model Fallback] Model ${model} encountered error:`, err?.message || err);
      lastError = err;
    }
  }
  throw lastError;
}

function cleanAndParseJson(rawText: string | undefined): any {
  if (!rawText) return {};
  let cleaned = rawText
    .replace(/^```json\s*/i, '')
    .replace(/^```\s*/i, '')
    .replace(/\s*```$/i, '')
    .trim();

  // Step 1: Standard JSON.parse
  try {
    return JSON.parse(cleaned);
  } catch (err) {
    // Step 2: jsonrepair (fixes unescaped quotes, missing commas, trailing commas, truncated brackets)
    try {
      const repaired = jsonrepair(cleaned);
      return JSON.parse(repaired);
    } catch (err2) {
      // Step 3: Extract JSON object substring and repair
      const startIdx = cleaned.indexOf('{');
      const endIdx = cleaned.lastIndexOf('}');
      if (startIdx !== -1) {
        const slice = endIdx !== -1 && endIdx > startIdx ? cleaned.substring(startIdx, endIdx + 1) : cleaned.substring(startIdx);
        try {
          const repaired = jsonrepair(slice);
          return JSON.parse(repaired);
        } catch (err3) {
          console.error('All JSON parsing attempts failed. Raw text preview:', cleaned.slice(0, 300));
          throw err;
        }
      }
      throw err;
    }
  }
}

const SYSTEM_PROMPT = `VAI TRÒ: CHUYÊN GIA NGÔN NGỮ TRUNG QUỐC – PINYIN – TIẾNG VIỆT
Bạn là chuyên gia ngôn ngữ Trung Quốc cao cấp, thành thạo tiếng Trung phổ thông (Mandarin), hệ thống phiên âm Hanyu Pinyin và tiếng Việt.

1. QUY TẮC DỊCH BẮT BUỘC:
- Xử lý theo thứ tự: Tiếng Trung gốc -> Pinyin -> Tiếng Việt -> Giải thích (khi cần hoặc khi có yêu cầu).
- Tiếng Trung gốc: Giữ nguyên chữ Hán, dấu câu, định dạng và cách chia câu. Nếu là phồn thể, giữ nguyên phồn thể, phiên âm theo Mandarin và dịch tiếng Việt.
- Pinyin: Chuẩn Hanyu Pinyin, CÓ ĐẦY ĐỦ DẤU THANH (mā, má, mǎ, mà), tuyệt đối không dùng Pinyin không dấu.
  * Tách từ hợp lý, giữ nguyên dấu câu tương ứng.
  * Tuân thủ quy tắc biến điệu thanh 3 (hai thanh 3 liên tiếp đọc 2-3), biến điệu của 不 (bù/bú) và 一 (yī/yí/yì).
  * Chú ý thanh nhẹ (khinh thanh) đúng quy chuẩn.
  * Phân biệt chính xác chữ Hán đồng âm hoặc đa âm (多音字: 得, 行, 了, 着, 地, 还, 重...) theo ngữ cảnh câu.
  * Nếu câu có lỗi chính tả hoặc thiếu ngữ cảnh: nêu rõ trong phần notes/ghi chú.
- Tiếng Việt:
  * Dịch tự nhiên, chính xác ngữ cảnh, thoát ý đúng văn phong người Việt.
  * Giữ nguyên sắc thái: lịch sự, thân mật, trang trọng, hài hước, tức giận, công sở...
  * Với thành ngữ (成语), tiếng lóng, từ viết tắt, từ lóng mạng: giải thích nghĩa thực tế thay vì dịch thô chữ-đối-chữ gây hiểu lầm.
  * Thuật ngữ chuyên ngành nhất quán.
  * Nếu có nhiều cách hiểu hợp lý, nêu các khả năng và chỉ rõ cách phù hợp nhất.

2. ĐỊNH DẠNG ĐẦU RA MẪU:
Nếu là câu đơn / đoạn văn:
Tiếng Trung:
你好，很高兴认识你。
Pinyin:
Nǐ hǎo, hěn gāoxìng rènshi nǐ.
Tiếng Việt:
Xin chào, rất vui được làm quen với bạn.

Nếu văn bản có nhiều câu, đánh số từng câu 1, 2, 3... tương ứng:
[Câu 1]
Tiếng Trung: ...
Pinyin: ...
Tiếng Việt: ...

[Câu 2]
Tiếng Trung: ...
Pinyin: ...
Tiếng Việt: ...

Khi có đoạn hội thoại, giữ nguyên nhân vật (ví dụ: A:, B: hoặc Tên nhân vật).`;

// POST /api/translate
app.post('/api/translate', async (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'application/json');

  try {
    const { text, mode = 'standard', includeAnalysis = false } = req.body;

    if (!text || typeof text !== 'string' || !text.trim()) {
      return res.status(400).json({ error: 'Vui lòng cung cấp văn bản tiếng Trung cần dịch.' });
    }

    const prompt = `Dịch và phân tích văn bản tiếng Trung sau đây theo đúng quy tắc chuyên gia (QUY TẮC BẮT BUỘC: Dịch đầy đủ 100% nội dung, không bỏ sót, không rút gọn, không dừng giữa chừng, bảo toàn mọi câu và lượt thoại):
Văn bản đầu vào:
"""
${text.trim()}
"""

Yêu cầu chế độ:
- Chế độ: ${mode} (${includeAnalysis ? 'Kèm phân tích chi tiết ngữ pháp và từ vựng' : 'Dịch chuẩn xác, phân tích từ vựng cốt lõi'})

Trả về định dạng JSON với cấu trúc:
{
  "detectedScript": "simplified" | "traditional" | "mixed",
  "textType": "single_word" | "single_sentence" | "paragraph" | "dialogue" | "idiom_chengyu" | "slang_internet" | "classical",
  "overallVietnamese": "Bản dịch tiếng Việt tổng thể mượt mà, tự nhiên",
  "formattedStandardText": "Chuỗi văn bản định dạng đúng theo mẫu quy định (Tiếng Trung, Pinyin, Tiếng Việt đối chiếu từng câu)",
  "sentences": [
    {
      "index": 1,
      "speaker": null,
      "chinese": "Câu tiếng Trung nguyên văn",
      "pinyin": "Pinyin chuẩn có dấu thanh và biến điệu",
      "vietnamese": "Dịch tiếng Việt tự nhiên chuẩn ngữ cảnh",
      "tokens": [
        {
          "chinese": "từ Hán",
          "pinyin": "pinyin có dấu",
          "hanViet": "âm Hán Việt",
          "meaning": "nghĩa tiếng Việt"
        }
      ],
      "notes": "Ghi chú nếu có"
    }
  ],
  "vocabulary": [
    {
      "chinese": "Từ vựng tiếng Hán",
      "pinyin": "Pinyin có dấu",
      "hanViet": "Âm Hán Việt",
      "meaning": "Nghĩa tiếng Việt chuẩn",
      "partOfSpeech": "Danh từ / Động từ...",
      "hskLevel": "HSK 1 đến 6",
      "exampleSentence": "Ví dụ",
      "examplePinyin": "Pinyin ví dụ",
      "exampleMeaning": "Nghĩa ví dụ"
    }
  ],
  "grammarPoints": [
    {
      "pattern": "Cấu trúc ngữ pháp",
      "explanation": "Giải thích",
      "example": "Ví dụ"
    }
  ],
  "slangOrIdioms": [
    {
      "term": "Thành ngữ hoặc tiếng lóng",
      "pinyin": "Pinyin",
      "literalMeaning": "Nghĩa đen",
      "actualMeaning": "Nghĩa thực tế trong đời sống",
      "contextNote": "Hoàn cảnh dùng"
    }
  ],
  "specialDisambiguations": [
    {
      "character": "Chữ đa âm",
      "usedReading": "Cách đọc ở đây",
      "otherReadings": "Các âm khác",
      "ruleExplanation": "Lý do chọn"
    }
  ]
}`;

    const response = await callGeminiWithFallback(async (modelName) => {
      return await ai.models.generateContent({
        model: modelName,
        contents: prompt,
        config: {
          maxOutputTokens: 8192,
          systemInstruction: SYSTEM_PROMPT + "\n\nQUY TẮC ĐẶC BIỆT KHI DỊCH ĐOẠN VĂN DÀI: Bạn phải tách văn bản đầu vào thành TẤT CẢ các câu riêng biệt (tính theo dấu chấm, chấm hỏi, dấu chấm than). Không được tóm tắt, không được bỏ sót bất kỳ câu nào từ đầu đến cuối đoạn. Mảng 'sentences' trong JSON phải chứa toàn bộ từng câu của đoạn văn.",
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              detectedScript: { type: Type.STRING },
              textType: { type: Type.STRING },
              overallVietnamese: { type: Type.STRING },
              formattedStandardText: { type: Type.STRING },
              sentences: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    index: { type: Type.INTEGER },
                    speaker: { type: Type.STRING, nullable: true },
                    chinese: { type: Type.STRING },
                    pinyin: { type: Type.STRING },
                    vietnamese: { type: Type.STRING },
                    tokens: {
                      type: Type.ARRAY,
                      items: {
                        type: Type.OBJECT,
                        properties: {
                          chinese: { type: Type.STRING },
                          pinyin: { type: Type.STRING },
                          hanViet: { type: Type.STRING },
                          meaning: { type: Type.STRING },
                        },
                        required: ['chinese', 'pinyin', 'meaning'],
                      },
                    },
                    notes: { type: Type.STRING, nullable: true },
                  },
                  required: ['index', 'chinese', 'pinyin', 'vietnamese', 'tokens'],
                },
              },
              vocabulary: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    chinese: { type: Type.STRING },
                    pinyin: { type: Type.STRING },
                    hanViet: { type: Type.STRING },
                    meaning: { type: Type.STRING },
                    partOfSpeech: { type: Type.STRING },
                    hskLevel: { type: Type.STRING, nullable: true },
                    exampleSentence: { type: Type.STRING, nullable: true },
                    examplePinyin: { type: Type.STRING, nullable: true },
                    exampleMeaning: { type: Type.STRING, nullable: true },
                  },
                  required: ['chinese', 'pinyin', 'hanViet', 'meaning', 'partOfSpeech'],
                },
              },
              grammarPoints: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    pattern: { type: Type.STRING },
                    explanation: { type: Type.STRING },
                    example: { type: Type.STRING },
                  },
                  required: ['pattern', 'explanation'],
                },
              },
              slangOrIdioms: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    term: { type: Type.STRING },
                    pinyin: { type: Type.STRING },
                    literalMeaning: { type: Type.STRING },
                    actualMeaning: { type: Type.STRING },
                    contextNote: { type: Type.STRING },
                  },
                  required: ['term', 'pinyin', 'actualMeaning'],
                },
              },
              specialDisambiguations: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    character: { type: Type.STRING },
                    usedReading: { type: Type.STRING },
                    otherReadings: { type: Type.STRING },
                    ruleExplanation: { type: Type.STRING },
                  },
                  required: ['character', 'usedReading', 'otherReadings', 'ruleExplanation'],
                },
              },
            },
            required: ['detectedScript', 'textType', 'overallVietnamese', 'formattedStandardText', 'sentences', 'vocabulary'],
          },
        },
      });
    });
    const parsedData = cleanAndParseJson(response.text);

    // Normalize result structure
    if (!parsedData.detectedScript) parsedData.detectedScript = 'simplified';
    if (!parsedData.textType) parsedData.textType = 'paragraph';
    if (!parsedData.overallVietnamese) parsedData.overallVietnamese = '';
    if (!Array.isArray(parsedData.sentences) || parsedData.sentences.length === 0) {
      parsedData.sentences = [
        {
          index: 1,
          speaker: null,
          chinese: text.trim(),
          pinyin: '',
          vietnamese: parsedData.overallVietnamese || '',
          tokens: [],
          notes: null,
        },
      ];
    }
    parsedData.sentences = parsedData.sentences.map((s: any, idx: number) => ({
      index: s.index || idx + 1,
      speaker: s.speaker || null,
      chinese: s.chinese || '',
      pinyin: s.pinyin || '',
      vietnamese: s.vietnamese || '',
      tokens: Array.isArray(s.tokens) ? s.tokens : [],
      notes: s.notes || null,
    }));

    if (!Array.isArray(parsedData.vocabulary)) parsedData.vocabulary = [];
    if (!Array.isArray(parsedData.grammarPoints)) parsedData.grammarPoints = [];
    if (!Array.isArray(parsedData.slangOrIdioms)) parsedData.slangOrIdioms = [];
    if (!Array.isArray(parsedData.specialDisambiguations)) parsedData.specialDisambiguations = [];

    return res.json(parsedData);
  } catch (error: any) {
    console.error('Translation error:', error);
    return res.status(500).json({
      error: 'Không thể xử lý bản dịch tiếng Trung vào lúc này.',
      details: error?.message || String(error),
    });
  }
});

// POST /api/ocr - Extract Chinese text from image
app.post('/api/ocr', async (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'application/json');

  try {
    const { imageBase64, mimeType = 'image/jpeg' } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: 'Vui lòng cung cấp hình ảnh base64.' });
    }

    const cleanBase64 = imageBase64.replace(/^data:image\/[a-zA-Z]+;base64,/, '');

    const response = await callGeminiWithFallback(async (modelName) => {
      return await ai.models.generateContent({
        model: modelName,
        contents: {
          parts: [
            {
              inlineData: {
                mimeType: mimeType,
                data: cleanBase64,
              },
            },
            {
              text: `Bạn là trợ lý nhận diện chữ Hán (OCR) và dịch tiếng Trung.
1. Hãy nhận diện chính xác toàn bộ chữ Hán trong bức ảnh này (cả Giản thể và Phồn thể).
2. Nếu có chữ bị mờ, che khuất hoặc không chắc chắn 100%, hãy đánh dấu rõ bằng ngoặc vuông hoặc chú thích [chữ không chắc chắn: X].
3. Giữ nguyên cấu trúc dòng, đoạn hoặc thứ tự người nói.

Trả về kết quả JSON với format:
{
  "extractedText": "Văn bản chữ Hán đầy đủ đã nhận diện",
  "uncertainCharacters": ["danh sách các chữ không chắc chắn nếu có"],
  "notes": "Ghi chú về chất lượng ảnh hoặc đặc điểm văn bản nhận diện được"
}`,
            },
          ],
        },
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              extractedText: { type: Type.STRING },
              uncertainCharacters: {
                type: Type.ARRAY,
                items: { type: Type.STRING },
              },
              notes: { type: Type.STRING },
            },
            required: ['extractedText', 'uncertainCharacters'],
          },
        },
      });
    });

    const ocrData = cleanAndParseJson(response.text);
    return res.json(ocrData);
  } catch (error: any) {
    console.error('OCR Error:', error);
    return res.status(500).json({
      error: 'Không thể nhận diện hình ảnh.',
      details: error?.message || String(error),
    });
  }
});

// POST /api/inspect-char - Deep dictionary lookup for single Hanzi character or word
app.post('/api/inspect-char', async (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'application/json');

  try {
    const { character, contextSentence } = req.body;

    if (!character) {
      return res.status(400).json({ error: 'Vui lòng cung cấp chữ Hán cần tra cứu.' });
    }

    const prompt = `Tra cứu chữ Hán/từ tiếng Trung: "${character}" ${contextSentence ? `trong ngữ cảnh câu: "${contextSentence}"` : ''}.
Hãy cung cấp thông tin chi tiết:
- Chữ Giản thể và Phồn thể tương ứng
- Pinyin chuẩn có dấu thanh (nêu rõ các âm đa âm 多音字 nếu có)
- Âm Hán Việt
- Bộ thủ (Radical) và số nét (Strokes)
- Cấp độ HSK (HSK 1 - 6)
- Nghĩa tiếng Việt chuẩn
- Từ loại
- Các từ ghép thông dụng chứa chữ này
- Ví dụ minh họa có Pinyin và dịch nghĩa tiếng Việt`;

    const response = await callGeminiWithFallback(async (modelName) => {
      return await ai.models.generateContent({
        model: modelName,
        contents: prompt,
        config: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              simplified: { type: Type.STRING },
              traditional: { type: Type.STRING },
              pinyin: { type: Type.STRING },
              hanViet: { type: Type.STRING },
              radical: { type: Type.STRING },
              strokeCount: { type: Type.INTEGER },
              hskLevel: { type: Type.STRING },
              partOfSpeech: { type: Type.STRING },
              primaryMeaning: { type: Type.STRING },
              polyphoneReadings: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    reading: { type: Type.STRING },
                    meaning: { type: Type.STRING },
                    sampleWord: { type: Type.STRING },
                  },
                  required: ['reading', 'meaning'],
                },
              },
              compoundWords: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    word: { type: Type.STRING },
                    pinyin: { type: Type.STRING },
                    hanViet: { type: Type.STRING },
                    meaning: { type: Type.STRING },
                  },
                  required: ['word', 'pinyin', 'meaning'],
                },
              },
              examples: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    chinese: { type: Type.STRING },
                    pinyin: { type: Type.STRING },
                    vietnamese: { type: Type.STRING },
                  },
                  required: ['chinese', 'pinyin', 'vietnamese'],
                },
              },
            },
            required: [
              'simplified',
              'traditional',
              'pinyin',
              'hanViet',
              'radical',
              'strokeCount',
              'primaryMeaning',
              'compoundWords',
              'examples',
            ],
          },
        },
      });
    });

    return res.json(cleanAndParseJson(response.text));
  } catch (error: any) {
    console.error('Character inspection error:', error);
    return res.status(500).json({ error: 'Không thể tra cứu chữ Hán.', details: error?.message });
  }
});

// POST /api/tts - Mandarin Text-to-Speech
app.post('/api/tts', async (req: Request, res: Response) => {
  res.setHeader('Content-Type', 'application/json');

  try {
    const { text, voice = 'Kore' } = req.body;

    if (!text || typeof text !== 'string') {
      return res.status(400).json({ error: 'Thiếu nội dung tiếng Trung phát âm.' });
    }

    const trimmed = text.slice(0, 400);

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash-lite-tts',
      contents: [
        {
          role: 'user',
          parts: [
            {
              text: trimmed,
              speechMetadata: {
                style: 'Natural standard Mandarin Chinese pronunciation, clear articulation with proper tones',
              },
            },
          ],
        },
      ],
      config: {
        responseModalities: ['AUDIO'],
        speechConfig: {
          voiceConfig: {
            prebuiltVoiceConfig: { voiceName: voice || 'Kore' },
          },
        },
      },
    });

    const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
    if (!base64Audio) {
      return res.json({ fallbackToBrowserTTS: true });
    }

    return res.json({ audioBase64: base64Audio, format: 'audio/wav' });
  } catch (error: any) {
    console.warn('TTS API error (fallback to Web Speech API enabled):', error?.message);
    return res.json({
      fallbackToBrowserTTS: true,
      message: 'Sử dụng phát âm trực tiếp từ trình duyệt.',
    });
  }
});

// Health check endpoint
app.get('/api/health', (_req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Setup Vite middleware in development or serve static files in production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req, res) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(Number(PORT), '0.0.0.0', () => {
    console.log(`Server listening on port ${PORT} (NODE_ENV=${process.env.NODE_ENV || 'development'})`);
  });
}

startServer();
